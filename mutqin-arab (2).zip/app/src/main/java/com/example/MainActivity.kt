package com.example

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.InitialVocabularyData
import com.example.data.Vocabulary
import com.example.ui.theme.MyApplicationTheme
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isTtsReady by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)

        setContent {
            MyApplicationTheme {
                MutqinArabApp(
                    onSpeak = { text -> speakArabic(text) }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ar"))
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
            }
        }
    }

    private fun speakArabic(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ArabicTTS")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

enum class CycleStep {
    INTRO, UNDERSTAND, RECALL, TEST, CONFIDENCE, SCHEDULE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MutqinArabApp(onSpeak: (String) -> Unit) {
    var vocabList by remember { mutableStateOf(InitialVocabularyData.items) }
    var activeStudyQueue by remember { mutableStateOf<List<Vocabulary>?>(null) }
    var currentQueueIndex by remember { mutableStateOf(0) }
    var currentCycleStep by remember { mutableStateOf(CycleStep.INTRO) }
    var isRecallRevealed by remember { mutableStateOf(false) }
    var selectedTestOption by remember { mutableStateOf<String?>(null) }
    var isTestSubmitted by remember { mutableStateOf(false) }
    var currentRating by remember { mutableStateOf("SEDANG") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Mutqin Arab",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Learn → Recall → Review → Master",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = "SRS Active",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (activeStudyQueue == null) {
                // HOME DASHBOARD
                HomeScreenCompose(
                    vocabList = vocabList,
                    onStartSession = { queue ->
                        activeStudyQueue = queue
                        currentQueueIndex = 0
                        currentCycleStep = CycleStep.INTRO
                        isRecallRevealed = false
                        selectedTestOption = null
                        isTestSubmitted = false
                    },
                    onSpeak = onSpeak
                )
            } else {
                // ACTIVE 7-STEP SRS CYCLE MODAL
                val currentWord = activeStudyQueue!![currentQueueIndex]

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Header progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kata ${currentQueueIndex + 1} dari ${activeStudyQueue!!.size}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(onClick = { activeStudyQueue = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup")
                        }
                    }

                    // Cycle step card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 8.dp),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            when (currentCycleStep) {
                                CycleStep.INTRO -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "SIKLUS 1: INTRODUCTION",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            text = currentWord.category,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = currentWord.arabic,
                                            fontSize = 48.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = currentWord.transliteration,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }
                                CycleStep.UNDERSTAND -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "SIKLUS 2: UNDERSTAND",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = currentWord.arabic,
                                            fontSize = 44.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = currentWord.transliteration,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = currentWord.meaning,
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        IconButton(onClick = { onSpeak(currentWord.arabic) }) {
                                            Icon(Icons.Default.VolumeUp, contentDescription = "Audio")
                                        }
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Surface(
                                            shape = RoundedCornerShape(16.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = "Contoh Kalimat:",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = currentWord.exampleArabic,
                                                    fontSize = 18.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                                Text(
                                                    text = "\"${currentWord.exampleMeaning}\"",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                                CycleStep.RECALL -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "SIKLUS 3: RECALL",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309)
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            text = currentWord.arabic,
                                            fontSize = 48.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        if (!isRecallRevealed) {
                                            Button(onClick = { isRecallRevealed = true }) {
                                                Text("Buka Arti (Periksa Ingatan)")
                                            }
                                        } else {
                                            Text(
                                                text = currentWord.meaning,
                                                fontSize = 22.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = currentWord.transliteration,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                    }
                                }
                                CycleStep.TEST -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "SIKLUS 4: TEST (PILIKAN GANDA)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = currentWord.arabic,
                                            fontSize = 40.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        val options = remember(currentWord) {
                                            (listOf(currentWord.meaning) + currentWord.distractors).shuffled()
                                        }
                                        options.forEach { opt ->
                                            OutlinedButton(
                                                onClick = {
                                                    selectedTestOption = opt
                                                    isTestSubmitted = true
                                                },
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    containerColor = if (isTestSubmitted && opt == currentWord.meaning) {
                                                        Color(0xFFD1FAE5)
                                                    } else if (isTestSubmitted && opt == selectedTestOption) {
                                                        Color(0xFFFFE4E6)
                                                    } else Color.Transparent
                                                )
                                            ) {
                                                Text(text = opt)
                                            }
                                        }
                                    }
                                }
                                CycleStep.CONFIDENCE -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "SIKLUS 5: CONFIDENCE (EVALUASI SRS)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "Seberapa mudah kamu mengingat kata ini?",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceEvenly
                                        ) {
                                            Button(
                                                onClick = {
                                                    currentRating = "AGAIN"
                                                    currentCycleStep = CycleStep.SCHEDULE
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                                            ) {
                                                Text("Tidak Tahu")
                                            }
                                            Button(
                                                onClick = {
                                                    currentRating = "SULIT"
                                                    currentCycleStep = CycleStep.SCHEDULE
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
                                            ) {
                                                Text("Sulit")
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceEvenly
                                        ) {
                                            Button(
                                                onClick = {
                                                    currentRating = "SEDANG"
                                                    currentCycleStep = CycleStep.SCHEDULE
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                            ) {
                                                Text("Sedang")
                                            }
                                            Button(
                                                onClick = {
                                                    currentRating = "MUDAH"
                                                    currentCycleStep = CycleStep.SCHEDULE
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                                            ) {
                                                Text("Mudah")
                                            }
                                        }
                                    }
                                }
                                CycleStep.SCHEDULE -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "SIKLUS 6 & 7: SCHEDULE & MASTER",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = currentWord.arabic,
                                            fontSize = 36.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = currentWord.meaning,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = if (currentRating == "AGAIN") {
                                                "⚠️ Tingkat penguasaan disesuaikan. Kata dijadwalkan ulas dalam 10 menit."
                                            } else {
                                                "✨ Hebat! Interval repetisi diperpanjang untuk memori jangka panjang."
                                            },
                                            fontSize = 13.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Navigation CTA
                    Button(
                        onClick = {
                            when (currentCycleStep) {
                                CycleStep.INTRO -> currentCycleStep = CycleStep.UNDERSTAND
                                CycleStep.UNDERSTAND -> currentCycleStep = CycleStep.RECALL
                                CycleStep.RECALL -> currentCycleStep = CycleStep.TEST
                                CycleStep.TEST -> currentCycleStep = CycleStep.CONFIDENCE
                                CycleStep.CONFIDENCE -> currentCycleStep = CycleStep.SCHEDULE
                                CycleStep.SCHEDULE -> {
                                    if (currentQueueIndex + 1 < activeStudyQueue!!.size) {
                                        currentQueueIndex += 1
                                        currentCycleStep = CycleStep.INTRO
                                        isRecallRevealed = false
                                        selectedTestOption = null
                                        isTestSubmitted = false
                                    } else {
                                        activeStudyQueue = null
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = if (currentCycleStep == CycleStep.SCHEDULE && currentQueueIndex + 1 >= activeStudyQueue!!.size) {
                                "Selesaikan Sesi"
                            } else if (currentCycleStep == CycleStep.SCHEDULE) {
                                "Lanjut ke Kata Berikutnya"
                            } else {
                                "Lanjut"
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreenCompose(
    vocabList: List<Vocabulary>,
    onStartSession: (List<Vocabulary>) -> Unit,
    onSpeak: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Sistem Spaced Repetition (SRS)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Learn → Recall → Review → Master",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Memfokuskan kata yang hampir lupa, sering salah, dan paling esensial untuk komunikasi.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { onStartSession(vocabList.take(5)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Mulai Sesi Belajar Prioritas (5 Kata)")
                    }
                }
            }
        }

        item {
            Text(
                text = "Daftar Kosakata Utama",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(vocabList) { item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().clickable { onStartSession(listOf(item)) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = item.meaning, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(text = item.transliteration, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(text = item.category, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = item.arabic, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { onSpeak(item.arabic) }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Dengar")
                        }
                    }
                }
            }
        }
    }
}
