package com.example.data

data class Vocabulary(
    val id: String,
    val arabic: String,
    val transliteration: String,
    val meaning: String,
    val category: String,
    val importance: Int,
    val exampleArabic: String,
    val exampleTransliteration: String,
    val exampleMeaning: String,
    val sentenceWords: List<String>,
    val distractors: List<String>,
    var status: String = "NEW", // NEW, LEARNING, REVIEWING, MASTERED
    var repetition: Int = 0,
    var intervalDays: Float = 0f,
    var easinessFactor: Float = 2.5f,
    var nextReviewTimestamp: Long = System.currentTimeMillis(),
    var masteryLevel: Int = 0,
    var totalReviews: Int = 0,
    var totalLapses: Int = 0,
    var consecutiveCorrect: Int = 0
)

object InitialVocabularyData {
    val items = listOf(
        Vocabulary(
            id = "vocab-1",
            arabic = "شُكْرًا",
            transliteration = "Syukran",
            meaning = "Terima kasih",
            category = "Percakapan & Sapaan",
            importance = 5,
            exampleArabic = "شُكْرًا جَزِيلًا عَلَى مُسَاعَدَتِكَ",
            exampleTransliteration = "Syukran jaziilan 'alaa musaa'adatika",
            exampleMeaning = "Terima kasih banyak atas bantuanmu",
            sentenceWords = listOf("شُكْرًا", "جَزِيلًا", "عَلَى", "مُسَاعَدَتِكَ"),
            distractors = listOf("Sama-sama", "Maafkan saya", "Selamat pagi")
        ),
        Vocabulary(
            id = "vocab-2",
            arabic = "عَفْوًا",
            transliteration = "'Afwan",
            meaning = "Sama-sama / Maaf",
            category = "Percakapan & Sapaan",
            importance = 5,
            exampleArabic = "عَفْوًا، لَا شُكْرَ عَلَى وَاجِبٍ",
            exampleTransliteration = "'Afwan, laa syukra 'alaa waajib",
            exampleMeaning = "Sama-sama, tidak perlu berterima kasih atas kewajiban",
            sentenceWords = listOf("عَفْوًا،", "لَا", "شُكْرَ", "عَلَى", "وَاجِبٍ"),
            distractors = listOf("Tolong", "Sampai jumpa", "Kabar baik")
        ),
        Vocabulary(
            id = "vocab-3",
            arabic = "مِنْ فَضْلِكَ",
            transliteration = "Min fadhlik",
            meaning = "Tolong / Permisi",
            category = "Percakapan & Sapaan",
            importance = 5,
            exampleArabic = "مِنْ فَضْلِكَ أَعْطِنِي الْمَاءَ",
            exampleTransliteration = "Min fadhlik a'thinii al-maa'",
            exampleMeaning = "Tolong beri saya air",
            sentenceWords = listOf("مِنْ", "فَضْلِكَ", "أَعْطِنِي", "الْمَاءَ"),
            distractors = listOf("Selamat jalan", "Berapa harganya", "Di mana")
        ),
        Vocabulary(
            id = "vocab-4",
            arabic = "كَيْفَ حَالُكَ؟",
            transliteration = "Kaifa haaluk?",
            meaning = "Bagaimana kabarmu?",
            category = "Percakapan & Sapaan",
            importance = 5,
            exampleArabic = "كَيْفَ حَالُكَ يَا أَخِي؟",
            exampleTransliteration = "Kaifa haaluka yaa akhii?",
            exampleMeaning = "Bagaimana kabarmu wahai saudaraku?",
            sentenceWords = listOf("كَيْفَ", "حَالُكَ", "يَا", "أَخِي؟"),
            distractors = listOf("Siapa namamu?", "Dari mana kamu?", "Mau ke mana?")
        ),
        Vocabulary(
            id = "vocab-5",
            arabic = "مَاءٌ",
            transliteration = "Maa'un",
            meaning = "Air",
            category = "Makanan & Minuman",
            importance = 5,
            exampleArabic = "أَشْرَبُ مَاءً بَارِدًا فِي الصَّيْفِ",
            exampleTransliteration = "Asyrabu maa'an baaridan fi ash-shayf",
            exampleMeaning = "Saya minum air dingin di musim panas",
            sentenceWords = listOf("أَشْرَبُ", "مَاءً", "بَارِدًا", "فِي", "الصَّيْفِ"),
            distractors = listOf("Susu", "Teh", "Roti")
        ),
        Vocabulary(
            id = "vocab-6",
            arabic = "خُبْزٌ",
            transliteration = "Khubzun",
            meaning = "Roti",
            category = "Makanan & Minuman",
            importance = 5,
            exampleArabic = "آكُلُ خُبْزًا طَازَجًا مَعَ الْجُبْنِ",
            exampleTransliteration = "Aakulu khubzan thaazajan ma'a al-jubni",
            exampleMeaning = "Saya makan roti segar dengan keju",
            sentenceWords = listOf("آكُلُ", "خُبْزًا", "طَازَجًا", "مَعَ", "الْجُبْنِ"),
            distractors = listOf("Nasi", "Daging", "Ikan")
        ),
        Vocabulary(
            id = "vocab-7",
            arabic = "بَيْتٌ",
            transliteration = "Baitun",
            meaning = "Rumah",
            category = "Di Rumah & Keluarga",
            importance = 5,
            exampleArabic = "بَيْتِي قَرِيبٌ مِنَ الْمَسْجِدِ الْكَبِيرِ",
            exampleTransliteration = "Baitii qariibun mina al-masjidil kabiir",
            exampleMeaning = "Rumah saya dekat dari masjid besar",
            sentenceWords = listOf("بَيْتِي", "قَرِيبٌ", "مِنَ", "الْمَسْجِدِ", "الْكَبِيرِ"),
            distractors = listOf("Kamar tidur", "Dapur", "Halaman")
        ),
        Vocabulary(
            id = "vocab-8",
            arabic = "كِتَابٌ",
            transliteration = "Kitaabun",
            meaning = "Buku",
            category = "Sekolah & Belajar",
            importance = 5,
            exampleArabic = "أَقْرَأُ كِتَابَ اللُّغَةِ الْعَرَبِيَّةِ يَوْمِيًّا",
            exampleTransliteration = "Aqra-u kitaaba al-lughatil 'arabiyyati yaumiyyan",
            exampleMeaning = "Saya membaca buku bahasa Arab setiap hari",
            sentenceWords = listOf("أَقْرَأُ", "كِتَابَ", "اللُّغَةِ", "الْعَرَبِيَّةِ", "يَوْمِيًّا"),
            distractors = listOf("Pena", "Meja", "Papan tulis")
        ),
        Vocabulary(
            id = "vocab-9",
            arabic = "سُوقٌ",
            transliteration = "Suuqun",
            meaning = "Pasar",
            category = "Pasar & Belanja",
            importance = 5,
            exampleArabic = "أَذْهَبُ إِلَى السُّوقِ لِشِرَاءِ الْخُضْرَاوَاتِ",
            exampleTransliteration = "Adzhabu ilaa as-suuqi lisyiraa-il khudhrawaati",
            exampleMeaning = "Saya pergi ke pasar untuk membeli sayur-mayur",
            sentenceWords = listOf("أَذْهَبُ", "إِلَى", "السُّوقِ", "لِشِرَاءِ", "الْخُضْرَاوَاتِ"),
            distractors = listOf("Toko buku", "Restoran", "Kantor pos")
        ),
        Vocabulary(
            id = "vocab-10",
            arabic = "بِكَمْ هَذَا؟",
            transliteration = "Bikam haadzaa?",
            meaning = "Berapa harga ini?",
            category = "Pasar & Belanja",
            importance = 5,
            exampleArabic = "بِكَمْ هَذَا الْقَمِيصُ الْأَزْرَقُ؟",
            exampleTransliteration = "Bikam haadzaa al-qamiishu al-azraqu?",
            exampleMeaning = "Berapa harga kemeja biru ini?",
            sentenceWords = listOf("بِكَمْ", "هَذَا", "الْقَمِيصُ", "الْأَزْرَقُ؟"),
            distractors = listOf("Di mana barang ini?", "Kapan buka?", "Boleh ditawar?")
        )
    )
}
