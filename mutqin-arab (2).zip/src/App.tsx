import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Navigation, NavTab } from './components/Navigation';
import { HomeScreen } from './screens/HomeScreen';
import { VocabularyListScreen } from './screens/VocabularyListScreen';
import { DrillModesScreen } from './screens/DrillModesScreen';
import { StatsScreen } from './screens/StatsScreen';
import { LoginScreen } from './screens/LoginScreen';
import { StudySessionModal } from './components/StudySessionModal';
import { InstallAppBanner } from './components/InstallAppBanner';
import { StorageService } from './services/storageService';
import { VocabularyItem, UserStats, UserProfile } from './types';

export function App() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => StorageService.getUserProfile());
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [vocabList, setVocabList] = useState<VocabularyItem[]>([]);
  const [stats, setStats] = useState<UserStats>(StorageService.getStats());
  const [activeSessionQueue, setActiveSessionQueue] = useState<VocabularyItem[] | null>(null);

  const loadData = useCallback(() => {
    setVocabList(StorageService.getVocabulary());
    setStats(StorageService.getStats());
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleLoginSuccess = (profile: UserProfile) => {
    StorageService.saveUserProfile(profile);
    setUserProfile(profile);
  };

  const handleLogout = () => {
    StorageService.logoutUser();
    setUserProfile(null);
  };

  const handleUpdateGoal = (newGoal: number) => {
    if (userProfile) {
      const updatedProfile: UserProfile = { ...userProfile, dailyGoal: newGoal };
      StorageService.saveUserProfile(updatedProfile);
      setUserProfile(updatedProfile);
    }
  };

  const handleUpdateVoice = (voice: 'male' | 'female') => {
    if (userProfile) {
      const updatedProfile: UserProfile = { ...userProfile, voiceGender: voice };
      StorageService.saveUserProfile(updatedProfile);
      setUserProfile(updatedProfile);
    }
  };

  // If user is not logged in, display the Login Screen slide
  if (!userProfile || !userProfile.isLoggedIn) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  const now = Date.now();
  const dueCount = vocabList.filter(v => v.nextReviewDate <= now).length;

  const handleStartSession = (queue: VocabularyItem[]) => {
    setActiveSessionQueue(queue);
  };

  const handleStartSingleWordSession = (item: VocabularyItem) => {
    setActiveSessionQueue([item]);
  };

  return (
    <div className="min-h-screen bg-[#ede3d1] flex flex-col justify-between">
      {/* Mobile App Container in Sandstone Parchment */}
      <div className="w-full max-w-md mx-auto min-h-screen bg-[#faf6ef] flex flex-col shadow-2xl border-x border-[#e4d6c0]">
        {/* Sticky Header */}
        <Header
          stats={stats}
          dueCount={dueCount}
          userProfile={userProfile}
          onLogout={handleLogout}
        />

        {/* Install on Phone Banner */}
        <div className="px-4 pt-2">
          <InstallAppBanner />
        </div>

        {/* Dynamic Screen Content */}
        <main className="flex-1">
          {activeTab === 'home' && (
            <HomeScreen
              vocabList={vocabList}
              stats={stats}
              userProfile={userProfile}
              onUpdateGoal={handleUpdateGoal}
              onStartSession={handleStartSession}
              onSelectWord={handleStartSingleWordSession}
            />
          )}

          {activeTab === 'vocab' && (
            <VocabularyListScreen
              vocabList={vocabList}
              onStartSingleWordSession={handleStartSingleWordSession}
            />
          )}

          {activeTab === 'drills' && (
            <DrillModesScreen vocabList={vocabList} />
          )}

          {activeTab === 'stats' && (
            <StatsScreen
              stats={stats}
              vocabList={vocabList}
              userProfile={userProfile}
              onUpdateGoal={handleUpdateGoal}
              onUpdateVoice={handleUpdateVoice}
              onRefresh={loadData}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <Navigation
          activeTab={activeTab}
          onChangeTab={setActiveTab}
          dueCount={dueCount}
        />

        {/* 7-Step Learn → Recall → Review → Master Session Modal */}
        {activeSessionQueue && activeSessionQueue.length > 0 && (
          <StudySessionModal
            queue={activeSessionQueue}
            allVocab={vocabList}
            onClose={() => setActiveSessionQueue(null)}
            onSessionComplete={() => {
              loadData();
              setActiveSessionQueue(null);
            }}
          />
        )}
      </div>
    </div>
  );
}

export default App;
