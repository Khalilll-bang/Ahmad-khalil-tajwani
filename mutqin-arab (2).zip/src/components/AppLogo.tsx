import React from 'react';

interface AppLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  textColor?: 'dark' | 'light';
  subtext?: string;
  className?: string;
}

export const AppLogo: React.FC<AppLogoProps> = ({
  size = 'md',
  showText = true,
  textColor = 'dark',
  subtext,
  className = '',
}) => {
  // Dimensions for the icon medallion
  const iconSizes = {
    sm: 'w-8 h-8 text-sm',
    md: 'w-10 h-10 text-base',
    lg: 'w-16 h-16 text-2xl',
    xl: 'w-24 h-24 text-4xl',
  };

  const titleSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Islamic Medallion / Calligraphy Badge in Desert Palette */}
      <div
        className={`${iconSizes[size]} relative shrink-0 rounded-2xl bg-gradient-to-tr from-desert-950 via-terracotta-700 to-amber-500 p-[1.5px] shadow-md shadow-desert-950/20 group`}
      >
        {/* Inner Gold / Sandstone Rim */}
        <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-desert-800 to-desert-950 flex flex-col items-center justify-center relative overflow-hidden border border-amber-400/40">
          {/* Subtle Arabesque Pattern Overlay */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:6px_6px] pointer-events-none" />

          {/* Central Calligraphy Arabic 40 */}
          <span className="font-arabic font-black text-amber-300 drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)] leading-none select-none tracking-tight">
            ٤٠
          </span>

          {size !== 'sm' && (
            <span className="font-arabic text-[9px] font-bold text-amber-100/90 leading-none -mt-0.5 tracking-tighter select-none">
              الأَرْبَعِين
            </span>
          )}
        </div>

        {/* Small Golden Corner Accents */}
        <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_4px_#fbbf24]" />
        <span className="absolute -bottom-0.5 -left-0.5 w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_4px_#fbbf24]" />
      </div>

      {/* Brand Text */}
      {showText && (
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-1.5">
            <h1
              className={`${titleSizes[size]} font-black tracking-tight leading-tight flex items-center gap-1.5 ${
                textColor === 'light' ? 'text-white' : 'text-dune-900'
              }`}
            >
              <span>Al-Arba'in 40</span>
              <span className="font-arabic text-xs font-bold px-1.5 py-0.5 rounded-md bg-amber-500/20 text-terracotta-700 border border-amber-500/30">
                الأَرْبَعِين
              </span>
            </h1>
          </div>
          <p
            className={`text-[11px] leading-tight mt-0.5 truncate ${
              textColor === 'light' ? 'text-desert-200/90' : 'text-dune-600 font-medium'
            }`}
          >
            {subtext || 'Spaced Repetition Kosakata Bahasa Arab'}
          </p>
        </div>
      )}
    </div>
  );
};
