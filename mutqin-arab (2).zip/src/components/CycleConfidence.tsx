import React from 'react';
import { ConfidenceRating, VocabularyItem } from '../types';
import { Sparkles, RotateCcw, AlertTriangle, ThumbsUp, Zap, HelpCircle } from 'lucide-react';

interface Props {
  item: VocabularyItem;
  testPassed: boolean;
  onRate: (rating: ConfidenceRating) => void;
}

export const CycleConfidence: React.FC<Props> = ({ item, testPassed, onRate }) => {
  return (
    <div className="flex flex-col items-center justify-between min-h-[480px] p-6 text-center animate-fadeIn">
      {/* Header */}
      <div className="w-full flex items-center justify-between mb-2">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-900">
          <HelpCircle className="w-3.5 h-3.5" /> SIKLUS 5: CONFIDENCE
        </span>
        <span className="text-xs text-slate-400 font-medium">Evaluasi SRS</span>
      </div>

      {/* Main Card */}
      <div className="w-full max-w-sm my-auto">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mb-4">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Seberapa mudah kamu mengingat kata ini?
          </span>

          <div className="my-3 py-1">
            <span className="font-arabic text-4xl font-bold text-slate-900 block select-none">
              {item.arabic}
            </span>
            <span className="text-base font-bold text-emerald-800 mt-1 block">
              {item.meaning}
            </span>
          </div>

          <p className="text-xs text-slate-500 mt-2">
            Pilihlah dengan jujur. Algoritma Spaced Repetition (SRS) akan mengkalkulasi jadwal pengulangan optimal untuk memori jangka panjangmu.
          </p>
        </div>

        {/* 4 Confidence Option Buttons */}
        <div className="grid grid-cols-2 gap-3 w-full">
          {/* 1. TIDAK TAHU (Again) */}
          <button
            onClick={() => onRate('again')}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition-all active:scale-95 ${
              !testPassed
                ? 'bg-rose-50 border-rose-300 ring-2 ring-rose-200'
                : 'bg-white hover:bg-rose-50/70 border-slate-200 hover:border-rose-200'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-rose-100 text-rose-700">
                <RotateCcw className="w-4 h-4" />
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-800">
                Ulangi
              </span>
            </div>
            <div>
              <span className="text-sm font-bold text-rose-950 block">Tidak Tahu</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Review dalam 10 menit</span>
            </div>
          </button>

          {/* 2. SULIT (Hard) */}
          <button
            onClick={() => onRate('hard')}
            className="p-4 rounded-2xl border bg-white hover:bg-amber-50/70 border-slate-200 hover:border-amber-200 text-left flex flex-col justify-between transition-all active:scale-95"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-amber-100 text-amber-700">
                <AlertTriangle className="w-4 h-4" />
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                Sulit
              </span>
            </div>
            <div>
              <span className="text-sm font-bold text-amber-950 block">Sulit</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Review ~12-24 jam</span>
            </div>
          </button>

          {/* 3. SEDANG (Good) */}
          <button
            onClick={() => onRate('good')}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition-all active:scale-95 ${
              testPassed
                ? 'bg-emerald-50/70 border-emerald-300 ring-1 ring-emerald-200'
                : 'bg-white hover:bg-emerald-50/70 border-slate-200 hover:border-emerald-200'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
                <ThumbsUp className="w-4 h-4" />
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                Normal
              </span>
            </div>
            <div>
              <span className="text-sm font-bold text-emerald-950 block">Sedang</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Review ~1-3 hari</span>
            </div>
          </button>

          {/* 4. MUDAH (Easy) */}
          <button
            onClick={() => onRate('easy')}
            className="p-4 rounded-2xl border bg-white hover:bg-blue-50/70 border-slate-200 hover:border-blue-200 text-left flex flex-col justify-between transition-all active:scale-95"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-blue-100 text-blue-700">
                <Zap className="w-4 h-4" />
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">
                Cepat
              </span>
            </div>
            <div>
              <span className="text-sm font-bold text-blue-950 block">Mudah</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Review ~4-7 hari</span>
            </div>
          </button>
        </div>
      </div>

      <div className="text-xs text-slate-400 mt-3">
        *Kejujuran evaluasi menjamin kosakata tersimpan di memori jangka panjang
      </div>
    </div>
  );
};
