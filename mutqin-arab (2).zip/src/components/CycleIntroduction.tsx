import React, { useState } from 'react';
import { VocabularyItem } from '../types';
import { Sparkles, Star, Tag, Compass, ArrowRight, Volume2 } from 'lucide-react';
import { SrsEngine } from '../services/srsEngine';
import { audioService } from '../services/audioService';

interface Props {
  item: VocabularyItem;
  onNext: () => void;
}

export const CycleIntroduction: React.FC<Props> = ({ item, onNext }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const isDue = item.nextReviewDate <= Date.now();
  const isLapsed = item.totalLapses > 0;
  const isNew = item.status === 'new';

  const playAudio = () => {
    setIsPlaying(true);
    audioService.speak(item.arabic, {
      onEnd: () => setIsPlaying(false),
      onError: () => setIsPlaying(false),
    });
  };

  let priorityReason = 'Kosakata penting untuk percakapan harian.';
  if (isDue && !isNew) {
    priorityReason = '⚠️ Hampir lupa! Waktunya meninjau sebelum ingatan memudar.';
  } else if (isLapsed) {
    priorityReason = '🔄 Sering keliru! Perlu pengulangan fokus untuk memperkuat ingatan.';
  } else if (isNew) {
    priorityReason = '✨ Kosakata baru! Masuk ke siklus pembelajaran awal.';
  }

  return (
    <div className="flex flex-col items-center justify-between min-h-[460px] p-6 text-center animate-fadeIn">
      {/* Top Badge */}
      <div className="w-full flex items-center justify-between mb-4">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
          <Sparkles className="w-3.5 h-3.5" /> SIKLUS 1: INTRODUCTION
        </span>
        <div className="flex items-center gap-1 text-amber-500">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-3.5 h-3.5 ${
                i < item.importance ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Main Intro Card */}
      <div className="my-auto w-full max-w-sm bg-gradient-to-b from-emerald-50 to-white border border-emerald-100/80 rounded-3xl p-6 shadow-sm">
        <div className="inline-block px-3 py-1 mb-4 rounded-xl bg-emerald-600/10 text-emerald-700 text-xs font-medium">
          {item.category}
        </div>

        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 mb-2">
          {isNew ? 'Kata Baru' : 'Ulas Kosakata'}
        </h3>

        {/* Large Arabic Word Preview */}
        <div className="my-4 py-3">
          <span className="font-arabic text-5xl text-emerald-900 leading-relaxed font-bold block select-none">
            {item.arabic}
          </span>
          <span className="text-sm font-medium text-emerald-700/80 italic mt-1 block">
            {item.transliteration}
          </span>

          {/* Quick Audio Play Button */}
          <div className="mt-3 flex justify-center">
            <button
              onClick={playAudio}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                isPlaying
                  ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-200'
                  : 'bg-emerald-100/70 hover:bg-emerald-100 text-emerald-800'
              }`}
            >
              <Volume2 className={`w-3.5 h-3.5 ${isPlaying ? 'animate-bounce' : ''}`} />
              <span>{isPlaying ? 'Memutar...' : 'Dengar Lafal'}</span>
            </button>
          </div>
        </div>

        {/* Priority Reason Banner */}
        <div className="mt-4 p-3 bg-white/90 border border-slate-100 rounded-2xl text-xs text-slate-600 text-left flex items-start gap-2 shadow-2xs">
          <Compass className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-800 block mb-0.5">Alasan Prioritas SRS:</span>
            {priorityReason}
          </div>
        </div>

        {/* Mastery indicator */}
        <div className="mt-4 flex items-center justify-between text-xs text-slate-500 border-t border-slate-100 pt-3">
          <span>Tingkat Memori:</span>
          <span className="font-semibold text-emerald-700">
            Level {item.masteryLevel} / 5 {item.masteryLevel === 5 ? '🏆 Mutqin' : ''}
          </span>
        </div>
      </div>

      {/* Action Button */}
      <button
        onClick={onNext}
        className="w-full max-w-sm mt-6 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-[0.98] transition-all"
      >
        <span>Mulai Pahami (Understand)</span>
        <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );
};
