import React, { useState } from 'react';
import { VocabularyItem } from '../types';
import { Brain, Eye, ArrowRight, CheckCircle2, Volume2 } from 'lucide-react';
import { audioService } from '../services/audioService';

interface Props {
  item: VocabularyItem;
  onNext: () => void;
}

export const CycleRecall: React.FC<Props> = ({ item, onNext }) => {
  const [isRevealed, setIsRevealed] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleAudio = () => {
    setIsPlaying(true);
    audioService.speak(item.arabic, {
      onEnd: () => setIsPlaying(false),
      onError: () => setIsPlaying(false),
    });
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[480px] p-6 text-center animate-fadeIn">
      {/* Top Header */}
      <div className="w-full flex items-center justify-between mb-2">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-900">
          <Brain className="w-3.5 h-3.5" /> SIKLUS 3: RECALL
        </span>
        <span className="text-xs text-slate-400 font-medium">
          Uji Ingatan Aktif
        </span>
      </div>

      {/* Main Recall Card */}
      <div className="w-full max-w-sm my-auto">
        <div className="bg-white border-2 border-dashed border-amber-200 rounded-3xl p-6 shadow-sm relative">
          <div className="mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-amber-700 bg-amber-50 px-3 py-1 rounded-full">
              Apa arti dari kata ini?
            </span>
          </div>

          {/* Large Arabic Word */}
          <div className="my-6 py-2">
            <span className="font-arabic text-6xl text-slate-900 font-bold block select-none leading-relaxed">
              {item.arabic}
            </span>
          </div>

          {/* Hidden or Revealed Section */}
          {!isRevealed ? (
            <div className="py-6 px-4 bg-slate-50 border border-slate-200/80 rounded-2xl">
              <p className="text-xs text-slate-500 mb-3 font-medium">
                Pikirkan artinya di kepalamu atau sebutkan secara lisan terlebih dahulu!
              </p>
              <button
                onClick={() => setIsRevealed(true)}
                className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
              >
                <Eye className="w-4 h-4" />
                <span>Buka Arti & Periksa Ingatan</span>
              </button>
            </div>
          ) : (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl animate-fadeIn">
              <div className="flex items-center justify-center gap-1 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-1">
                <CheckCircle2 className="w-4 h-4" /> Kunci Jawaban
              </div>
              <p className="text-2xl font-bold text-emerald-950 my-1">
                {item.meaning}
              </p>
              <p className="text-xs font-medium text-emerald-700 italic">
                {item.transliteration}
              </p>

              <button
                onClick={handleAudio}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 hover:bg-emerald-200 transition-colors"
              >
                <Volume2 className={`w-3.5 h-3.5 ${isPlaying ? 'animate-bounce' : ''}`} />
                <span>Dengar Pelafalan</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Action Next (only enabled after revealed) */}
      <button
        onClick={onNext}
        disabled={!isRevealed}
        className={`w-full max-w-sm mt-4 py-4 px-6 rounded-2xl font-semibold flex items-center justify-center gap-2 transition-all ${
          isRevealed
            ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 active:scale-[0.98]'
            : 'bg-slate-200 text-slate-400 cursor-not-allowed'
        }`}
      >
        <span>Lanjut ke Tes Pemahaman (Test)</span>
        <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );
};
