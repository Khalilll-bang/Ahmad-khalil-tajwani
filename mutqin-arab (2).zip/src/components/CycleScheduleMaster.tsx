import React, { useEffect } from 'react';
import { VocabularyItem, ConfidenceRating } from '../types';
import { Calendar, Award, CheckCircle2, AlertTriangle, ArrowRight, Volume2, Sparkles, TrendingUp, TrendingDown } from 'lucide-react';
import confetti from 'canvas-confetti';
import { audioService } from '../services/audioService';

interface Props {
  oldItem: VocabularyItem;
  updatedItem: VocabularyItem;
  explanation: string;
  nextDueFormatted: string;
  rating: ConfidenceRating;
  isSessionFinished: boolean;
  onContinue: () => void;
}

export const CycleScheduleMaster: React.FC<Props> = ({
  oldItem,
  updatedItem,
  explanation,
  nextDueFormatted,
  rating,
  isSessionFinished,
  onContinue,
}) => {
  const isMastered = updatedItem.status === 'mastered' || updatedItem.masteryLevel >= 5;
  const isLapsed = rating === 'again' || updatedItem.masteryLevel < oldItem.masteryLevel;
  const masteryImproved = updatedItem.masteryLevel > oldItem.masteryLevel;

  useEffect(() => {
    if (isMastered && !isLapsed) {
      // Fire celebration confetti
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#059669', '#10b981', '#f59e0b', '#3b82f6'],
        });
      } catch (e) {
        // ignore if not supported
      }
    }
  }, [isMastered, isLapsed]);

  const playWord = () => {
    audioService.speak(updatedItem.arabic);
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[500px] p-6 text-center animate-fadeIn">
      {/* Step Header */}
      <div className="w-full flex items-center justify-between mb-2">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-900">
          <Calendar className="w-3.5 h-3.5" /> SIKLUS 6 & 7: SCHEDULE & MASTER
        </span>
        <span className="text-xs text-slate-400 font-medium">SRS Log</span>
      </div>

      {/* Main Results Card */}
      <div className="w-full max-w-sm my-auto space-y-4">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm relative overflow-hidden">
          {/* Status Badge */}
          <div className="flex items-center justify-center gap-1.5 mb-3">
            {isMastered ? (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-extrabold bg-amber-100 text-amber-900 border border-amber-200">
                <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" /> STATUS: MUTQIN (MASTERED)
              </span>
            ) : isLapsed ? (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800">
                <TrendingDown className="w-3.5 h-3.5" /> PERLU PENGUATAN (LAPSE)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                <TrendingUp className="w-3.5 h-3.5" /> MEMORI SEMAKIN KUAT
              </span>
            )}
          </div>

          {/* Word display */}
          <div className="my-2">
            <span className="font-arabic text-4xl font-bold text-slate-900 block select-none">
              {updatedItem.arabic}
            </span>
            <span className="text-sm font-semibold text-slate-700 mt-1 block">
              {updatedItem.meaning}
            </span>

            {/* Audio review button */}
            <div className="mt-2.5 flex justify-center">
              <button
                onClick={playWord}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Ulas Audio</span>
              </button>
            </div>
          </div>

          {/* Schedule Calculation Banner */}
          <div className="mt-4 p-4 bg-slate-50 border border-slate-100 rounded-2xl text-left space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Jadwal Review Berikutnya:</span>
              <span className="font-bold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded-md">
                {nextDueFormatted}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Interval Repetisi:</span>
              <span className="font-semibold text-slate-800">
                {updatedItem.intervalDays >= 1
                  ? `${Math.round(updatedItem.intervalDays)} Hari`
                  : `${Math.round(updatedItem.intervalDays * 24 * 60)} Menit`}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Konsistensi Benar:</span>
              <span className="font-semibold text-slate-800">
                {updatedItem.consecutiveCorrect}x beruntun
              </span>
            </div>
          </div>

          {/* Mastery Progress Bar */}
          <div className="mt-4 text-left">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-medium text-slate-600">Tingkat Penguasaan:</span>
              <span className="font-bold text-slate-800">
                Level {updatedItem.masteryLevel} / 5
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className={`flex-1 border-r border-white/60 first:rounded-l-full last:rounded-r-full transition-all duration-500 ${
                    i < updatedItem.masteryLevel
                      ? updatedItem.masteryLevel === 5
                        ? 'bg-amber-400'
                        : 'bg-emerald-500'
                      : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Explanation Text */}
          <p className="mt-4 text-xs text-slate-600 italic leading-relaxed">
            "{explanation}"
          </p>
        </div>

        {/* If Lapsed: Show Remedial Word Card with Example Sentence */}
        {isLapsed && (
          <div className="p-4 bg-amber-50/90 border border-amber-200 rounded-2xl text-left text-xs animate-fadeIn">
            <div className="flex items-center justify-between font-bold text-amber-900 mb-1">
              <span>Pengingat Contoh Kalimat:</span>
              <button
                onClick={playWord}
                className="p-1 rounded bg-amber-200/70 hover:bg-amber-200 text-amber-900"
                title="Dengar"
              >
                <Volume2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="font-arabic text-base font-bold text-slate-800 text-right my-1">
              {updatedItem.exampleArabic}
            </p>
            <p className="text-slate-600 italic">"{updatedItem.exampleMeaning}"</p>
          </div>
        )}
      </div>

      {/* Continue Button */}
      <button
        onClick={onContinue}
        className="w-full max-w-sm mt-4 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-[0.98] transition-all"
      >
        <span>{isSessionFinished ? 'Selesaikan Sesi Belajar' : 'Lanjut ke Kata Berikutnya'}</span>
        <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );
};
