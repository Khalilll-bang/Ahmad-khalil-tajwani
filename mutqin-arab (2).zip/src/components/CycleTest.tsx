import React, { useState, useEffect, useMemo } from 'react';
import { VocabularyItem, TestType } from '../types';
import {
  CheckCircle,
  XCircle,
  Volume2,
  HelpCircle,
  ArrowRight,
  Shuffle,
  Headphones,
  Keyboard,
  ListOrdered,
  Layers,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { audioService } from '../services/audioService';

interface Props {
  item: VocabularyItem;
  allVocab: VocabularyItem[];
  preferredMode?: TestType;
  onComplete: (passed: boolean, modeUsed: TestType) => void;
}

export const CycleTest: React.FC<Props> = ({ item, allVocab, preferredMode, onComplete }) => {
  // Determine test mode: if none specified, choose smartly
  const testMode = useMemo<TestType>(() => {
    if (preferredMode) return preferredMode;
    // Rotate among the 5 types based on word ID hash
    const modes: TestType[] = ['multiple_choice', 'listening', 'typing', 'sentence_scramble', 'matching'];
    const charCodeSum = item.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
    return modes[charCodeSum % modes.length];
  }, [item.id, preferredMode]);

  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Mode 1: Multiple Choice Options
  const multipleChoiceOptions = useMemo(() => {
    const opts = [item.meaning, ...(item.distractors || ['Air', 'Buku', 'Rumah'])];
    return [...opts].sort(() => 0.5 - Math.random());
  }, [item]);
  const [selectedMCOption, setSelectedMCOption] = useState<string | null>(null);

  // Mode 2: Listening Test Options (Audio only, choices can be Indonesian or Arabic)
  const listeningOptions = useMemo(() => {
    const opts = [item.meaning, ...(item.distractors || ['Air', 'Buku', 'Rumah'])];
    return [...opts].sort(() => 0.5 - Math.random());
  }, [item]);
  const [selectedListeningOption, setSelectedListeningOption] = useState<string | null>(null);

  // Mode 3: Typing / Speller Input
  const [typedInput, setTypedInput] = useState('');

  // Mode 4: Sentence Scramble (Susun Kalimat)
  const scrambledSentenceWords = useMemo(() => {
    const original = [...(item.sentenceWords || item.exampleArabic.split(' '))];
    const shuffled = [...original].sort(() => 0.5 - Math.random());
    return shuffled.map((word, idx) => ({ id: `${word}-${idx}`, word, originalIndex: idx }));
  }, [item]);
  const [arrangedTokens, setArrangedTokens] = useState<Array<{ id: string; word: string }>>([]);
  const [availableTokens, setAvailableTokens] = useState<Array<{ id: string; word: string }>>([]);

  // Mode 5: Matching Pairs (Cocokkan 3 pasangan)
  const matchingPairs = useMemo(() => {
    // Current item + 2 other random items
    const otherItems = allVocab.filter(v => v.id !== item.id).slice(0, 2);
    const combined = [item, ...otherItems];
    const arabicCards = combined.map(c => ({ id: c.id, text: c.arabic, type: 'arabic' as const }));
    const meaningCards = combined.map(c => ({ id: c.id, text: c.meaning, type: 'meaning' as const }));
    return {
      arabicCards: [...arabicCards].sort(() => 0.5 - Math.random()),
      meaningCards: [...meaningCards].sort(() => 0.5 - Math.random()),
      totalPairs: combined.length,
    };
  }, [item, allVocab]);

  const [selectedArabicCard, setSelectedArabicCard] = useState<string | null>(null);
  const [selectedMeaningCard, setSelectedMeaningCard] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);

  // Initialize Sentence tokens
  useEffect(() => {
    setAvailableTokens(scrambledSentenceWords);
    setArrangedTokens([]);
    setHasSubmitted(false);
    setIsCorrect(false);
    setSelectedMCOption(null);
    setSelectedListeningOption(null);
    setTypedInput('');
    setMatchedIds([]);
  }, [item, scrambledSentenceWords]);

  // Auto-play audio on listening test entry
  useEffect(() => {
    if (testMode === 'listening') {
      playAudio();
    }
  }, [testMode]);

  const playAudio = () => {
    setIsPlayingAudio(true);
    audioService.speak(item.arabic, {
      onEnd: () => setIsPlayingAudio(false),
      onError: () => setIsPlayingAudio(false),
    });
  };

  // Evaluate Multiple Choice
  const handleSelectMC = (option: string) => {
    if (hasSubmitted) return;
    setSelectedMCOption(option);
    const correct = option.trim().toLowerCase() === item.meaning.trim().toLowerCase();
    setIsCorrect(correct);
    setHasSubmitted(true);
  };

  // Evaluate Listening
  const handleSelectListening = (option: string) => {
    if (hasSubmitted) return;
    setSelectedListeningOption(option);
    const correct = option.trim().toLowerCase() === item.meaning.trim().toLowerCase();
    setIsCorrect(correct);
    setHasSubmitted(true);
  };

  // Evaluate Typing
  const handleSubmitTyping = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!typedInput.trim() || hasSubmitted) return;

    // Check if matches meaning or transliteration closely
    const cleanTyped = typedInput.trim().toLowerCase();
    const cleanMeaning = item.meaning.toLowerCase();
    const cleanTranslit = item.transliteration.toLowerCase();

    const correct =
      cleanTyped === cleanMeaning ||
      cleanMeaning.includes(cleanTyped) ||
      cleanTyped === cleanTranslit ||
      cleanTyped === item.arabicClean;

    setIsCorrect(correct);
    setHasSubmitted(true);
  };

  // Sentence Scramble handlers
  const handleSelectToken = (token: { id: string; word: string }) => {
    if (hasSubmitted) return;
    setArrangedTokens(prev => [...prev, token]);
    setAvailableTokens(prev => prev.filter(t => t.id !== token.id));
  };

  const handleRemoveToken = (token: { id: string; word: string }) => {
    if (hasSubmitted) return;
    setArrangedTokens(prev => prev.filter(t => t.id !== token.id));
    setAvailableTokens(prev => [...prev, token]);
  };

  const handleVerifySentence = () => {
    const arrangedSentence = arrangedTokens.map(t => t.word).join(' ').trim();
    const targetSentence = (item.sentenceWords || item.exampleArabic.split(' ')).join(' ').trim();

    // Check equality (allowing slight punctuation difference)
    const normalize = (str: string) => str.replace(/[.,?!]/g, '').trim();
    const correct = normalize(arrangedSentence) === normalize(targetSentence);

    setIsCorrect(correct);
    setHasSubmitted(true);
  };

  // Matching pair handler
  const handleSelectPairCard = (id: string, type: 'arabic' | 'meaning') => {
    if (hasSubmitted) return;

    if (type === 'arabic') {
      setSelectedArabicCard(id);
      if (selectedMeaningCard) {
        // Evaluate pair
        if (id === selectedMeaningCard) {
          const newMatched = [...matchedIds, id];
          setMatchedIds(newMatched);
          setSelectedArabicCard(null);
          setSelectedMeaningCard(null);
          if (newMatched.length === matchingPairs.totalPairs) {
            setIsCorrect(true);
            setHasSubmitted(true);
          }
        } else {
          // Mismatch
          setTimeout(() => {
            setSelectedArabicCard(null);
            setSelectedMeaningCard(null);
          }, 600);
        }
      }
    } else {
      setSelectedMeaningCard(id);
      if (selectedArabicCard) {
        if (id === selectedArabicCard) {
          const newMatched = [...matchedIds, id];
          setMatchedIds(newMatched);
          setSelectedArabicCard(null);
          setSelectedMeaningCard(null);
          if (newMatched.length === matchingPairs.totalPairs) {
            setIsCorrect(true);
            setHasSubmitted(true);
          }
        } else {
          setTimeout(() => {
            setSelectedArabicCard(null);
            setSelectedMeaningCard(null);
          }, 600);
        }
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[500px] p-6 text-center animate-fadeIn">
      {/* Test Mode Header */}
      <div className="w-full flex items-center justify-between mb-3">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-900">
          <HelpCircle className="w-3.5 h-3.5" /> SIKLUS 4: TEST
        </span>
        <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
          {testMode === 'multiple_choice' && <Layers className="w-3.5 h-3.5 text-purple-600" />}
          {testMode === 'listening' && <Headphones className="w-3.5 h-3.5 text-blue-600" />}
          {testMode === 'typing' && <Keyboard className="w-3.5 h-3.5 text-amber-600" />}
          {testMode === 'sentence_scramble' && <ListOrdered className="w-3.5 h-3.5 text-emerald-600" />}
          {testMode === 'matching' && <Shuffle className="w-3.5 h-3.5 text-indigo-600" />}
          <span className="capitalize">
            {testMode === 'multiple_choice' && 'Pilihan Ganda'}
            {testMode === 'listening' && 'Uji Mendengarkan'}
            {testMode === 'typing' && 'Ketik Arti'}
            {testMode === 'sentence_scramble' && 'Susun Kalimat'}
            {testMode === 'matching' && 'Cocokkan Pasangan'}
          </span>
        </span>
      </div>

      {/* Main Testing View */}
      <div className="w-full max-w-sm my-auto space-y-4">
        {/* 1. MULTIPLE CHOICE MODE */}
        {testMode === 'multiple_choice' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
            <span className="text-xs text-slate-400 font-medium">Pilih arti yang tepat untuk:</span>
            <div className="my-3">
              <span className="font-arabic text-5xl font-bold text-slate-900 block select-none">
                {item.arabic}
              </span>
              <span className="text-xs text-emerald-700 italic font-medium mt-1 block">
                {item.transliteration}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2.5 mt-4">
              {multipleChoiceOptions.map((opt, idx) => {
                const isSelected = selectedMCOption === opt;
                const isTarget = opt === item.meaning;
                let btnStyle = 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800';

                if (hasSubmitted) {
                  if (isTarget) {
                    btnStyle = 'bg-emerald-500 border-emerald-600 text-white font-bold ring-2 ring-emerald-200';
                  } else if (isSelected && !isTarget) {
                    btnStyle = 'bg-rose-500 border-rose-600 text-white line-through';
                  } else {
                    btnStyle = 'opacity-50 bg-slate-50 border-slate-100 text-slate-400';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={hasSubmitted}
                    onClick={() => handleSelectMC(opt)}
                    className={`w-full py-3 px-4 rounded-xl border text-sm font-medium transition-all text-left flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {hasSubmitted && isTarget && <CheckCircle className="w-4 h-4 text-white shrink-0" />}
                    {hasSubmitted && isSelected && !isTarget && <XCircle className="w-4 h-4 text-white shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. LISTENING TEST MODE */}
        {testMode === 'listening' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
            <span className="text-xs text-slate-400 font-medium">
              Dengarkan lafal audio berikut, lalu pilih artinya:
            </span>

            {/* Big Audio Play Button */}
            <div className="my-5 flex flex-col items-center">
              <button
                onClick={playAudio}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                  isPlayingAudio
                    ? 'bg-blue-600 text-white scale-105 ring-8 ring-blue-100 animate-pulse'
                    : 'bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-200 shadow-sm'
                }`}
              >
                <Volume2 className="w-10 h-10" />
              </button>
              <span className="text-xs font-semibold text-blue-700 mt-2">
                {isPlayingAudio ? 'Sedang memutar audio...' : 'Ketuk untuk dengarkan lagi'}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              {listeningOptions.map((opt, idx) => {
                const isSelected = selectedListeningOption === opt;
                const isTarget = opt === item.meaning;
                let btnStyle = 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800';

                if (hasSubmitted) {
                  if (isTarget) {
                    btnStyle = 'bg-emerald-500 border-emerald-600 text-white font-bold ring-2 ring-emerald-200';
                  } else if (isSelected && !isTarget) {
                    btnStyle = 'bg-rose-500 border-rose-600 text-white line-through';
                  } else {
                    btnStyle = 'opacity-50 bg-slate-50 border-slate-100 text-slate-400';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={hasSubmitted}
                    onClick={() => handleSelectListening(opt)}
                    className={`w-full py-3 px-4 rounded-xl border text-sm font-medium transition-all text-left flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {hasSubmitted && isTarget && <CheckCircle className="w-4 h-4 text-white shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. TYPING TEST MODE */}
        {testMode === 'typing' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm text-left">
            <span className="text-xs text-slate-400 font-medium block text-center">
              Ketik arti atau transliterasi kata ini:
            </span>
            <div className="my-3 text-center">
              <span className="font-arabic text-5xl font-bold text-slate-900 block select-none">
                {item.arabic}
              </span>
            </div>

            <form onSubmit={handleSubmitTyping} className="space-y-3 mt-4">
              <input
                type="text"
                value={typedInput}
                disabled={hasSubmitted}
                onChange={e => setTypedInput(e.target.value)}
                placeholder="Contoh: terima kasih / syukran"
                className="w-full py-3 px-4 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm font-medium"
                autoFocus
              />

              {!hasSubmitted ? (
                <button
                  type="submit"
                  disabled={!typedInput.trim()}
                  className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-200 text-white font-semibold text-sm transition-all"
                >
                  Periksa Ejaan
                </button>
              ) : null}
            </form>
          </div>
        )}

        {/* 4. SENTENCE SCRAMBLE (SUSUN KALIMAT) */}
        {testMode === 'sentence_scramble' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
            <span className="text-xs text-slate-400 font-medium block mb-1">
              Susun kata-kata Arab berikut menjadi kalimat yang benar:
            </span>
            <p className="text-xs font-semibold text-emerald-800 bg-emerald-50 py-1.5 px-3 rounded-lg mb-3">
              Arti: "{item.exampleMeaning}"
            </p>

            {/* Drop / arranged area */}
            <div className="min-h-[70px] p-3 border-2 border-dashed border-emerald-300 rounded-2xl bg-emerald-50/50 flex flex-wrap gap-2 items-center justify-center">
              {arrangedTokens.length === 0 ? (
                <span className="text-xs text-emerald-600/70 italic">Ketuk potongan kata di bawah untuk menyusun</span>
              ) : (
                arrangedTokens.map(tok => (
                  <button
                    key={tok.id}
                    disabled={hasSubmitted}
                    onClick={() => handleRemoveToken(tok)}
                    className="font-arabic text-xl px-3 py-1 bg-white border border-emerald-300 rounded-xl shadow-xs text-emerald-950 font-bold active:scale-95 transition-all"
                  >
                    {tok.word}
                  </button>
                ))
              )}
            </div>

            {/* Available chips to tap */}
            <div className="mt-3 flex flex-wrap gap-2 justify-center">
              {availableTokens.map(tok => (
                <button
                  key={tok.id}
                  disabled={hasSubmitted}
                  onClick={() => handleSelectToken(tok)}
                  className="font-arabic text-xl px-3 py-1 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-slate-800 font-bold active:scale-95 transition-all"
                >
                  {tok.word}
                </button>
              ))}
            </div>

            {!hasSubmitted && arrangedTokens.length > 0 && (
              <button
                onClick={handleVerifySentence}
                className="w-full mt-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-all shadow-sm"
              >
                Periksa Susunan Kalimat
              </button>
            )}
          </div>
        )}

        {/* 5. MATCHING PAIRS */}
        {testMode === 'matching' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
            <span className="text-xs text-slate-400 font-medium block mb-3">
              Cocokkan pasangan kata Arab dengan arti Indonesianya:
            </span>

            <div className="grid grid-cols-2 gap-3">
              {/* Arabic column */}
              <div className="space-y-2">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Bahasa Arab</span>
                {matchingPairs.arabicCards.map(c => {
                  const isMatched = matchedIds.includes(c.id);
                  const isSelected = selectedArabicCard === c.id;
                  return (
                    <button
                      key={c.id}
                      disabled={isMatched}
                      onClick={() => handleSelectPairCard(c.id, 'arabic')}
                      className={`w-full py-2.5 px-2 rounded-xl border text-center transition-all ${
                        isMatched
                          ? 'opacity-40 bg-emerald-100 border-emerald-300 text-emerald-900 line-through'
                          : isSelected
                          ? 'bg-purple-600 text-white border-purple-700 shadow-md ring-2 ring-purple-200'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-900'
                      }`}
                    >
                      <span className="font-arabic text-2xl font-bold block">{c.text}</span>
                    </button>
                  );
                })}
              </div>

              {/* Meaning column */}
              <div className="space-y-2">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Arti Indonesia</span>
                {matchingPairs.meaningCards.map(c => {
                  const isMatched = matchedIds.includes(c.id);
                  const isSelected = selectedMeaningCard === c.id;
                  return (
                    <button
                      key={c.id}
                      disabled={isMatched}
                      onClick={() => handleSelectPairCard(c.id, 'meaning')}
                      className={`w-full py-3 px-2 rounded-xl border text-center text-xs font-semibold transition-all ${
                        isMatched
                          ? 'opacity-40 bg-emerald-100 border-emerald-300 text-emerald-900 line-through'
                          : isSelected
                          ? 'bg-purple-600 text-white border-purple-700 shadow-md ring-2 ring-purple-200'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
                      }`}
                    >
                      {c.text}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* FEEDBACK BANNER (If submitted) */}
        {hasSubmitted && (
          <div
            className={`p-4 rounded-2xl text-left border animate-fadeIn ${
              isCorrect
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-950'
            }`}
          >
            <div className="flex items-center gap-2 font-bold text-sm mb-1">
              {isCorrect ? (
                <>
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>Jawaban Benar! Ingatan terverifikasi.</span>
                </>
              ) : (
                <>
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                  <span>Jawaban Belum Tepat</span>
                </>
              )}
            </div>

            {!isCorrect && (
              <div className="text-xs space-y-1.5 mt-2 pt-2 border-t border-rose-200/80">
                <p>
                  Kunci arti yang benar: <strong className="text-rose-900">{item.meaning}</strong> ({item.transliteration})
                </p>
                <div className="p-2 bg-white/80 rounded-xl border border-rose-100 mt-1">
                  <span className="text-[10px] text-slate-500 font-bold block mb-0.5">Contoh kalimat pengingat:</span>
                  <p className="font-arabic text-base font-bold text-slate-800 text-right">
                    {item.exampleArabic}
                  </p>
                  <p className="text-[11px] text-slate-600 italic">"{item.exampleMeaning}"</p>
                </div>
                <p className="text-[11px] text-rose-700 font-medium">
                  ⚠️ Jangan khawatir! Tingkat penguasaan akan disesuaikan dan kata ini akan diulang lebih cepat.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Next Button */}
      {hasSubmitted && (
        <button
          onClick={() => onComplete(isCorrect, testMode)}
          className="w-full max-w-sm mt-4 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-[0.98] transition-all animate-fadeIn"
        >
          <span>Lanjut ke Evaluasi Keyakinan (Confidence)</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      )}
    </div>
  );
};
