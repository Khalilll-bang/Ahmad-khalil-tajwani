import React, { useState } from 'react';
import { VocabularyItem } from '../types';
import { Volume2, VolumeX, BookOpen, ArrowRight, Gauge, HelpCircle } from 'lucide-react';
import { audioService } from '../services/audioService';

interface Props {
  item: VocabularyItem;
  onNext: () => void;
}

export const CycleUnderstand: React.FC<Props> = ({ item, onNext }) => {
  const [isPlayingWord, setIsPlayingWord] = useState(false);
  const [isPlayingExample, setIsPlayingExample] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(0.85);

  const playWord = () => {
    setIsPlayingWord(true);
    audioService.speak(item.arabic, {
      rate: speechRate,
      onEnd: () => setIsPlayingWord(false),
      onError: () => setIsPlayingWord(false),
    });
  };

  const playExample = () => {
    setIsPlayingExample(true);
    audioService.speak(item.exampleArabic, {
      rate: speechRate,
      onEnd: () => setIsPlayingExample(false),
      onError: () => setIsPlayingExample(false),
    });
  };

  const toggleRate = () => {
    setSpeechRate(prev => (prev === 0.85 ? 0.65 : 0.85));
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[500px] p-6 text-center animate-fadeIn">
      {/* Header Badge */}
      <div className="w-full flex items-center justify-between mb-2">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
          <BookOpen className="w-3.5 h-3.5" /> SIKLUS 2: UNDERSTAND
        </span>

        {/* Audio Speed Rate Button */}
        <button
          onClick={toggleRate}
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          title="Kecepatan Audio"
        >
          <Gauge className="w-3 h-3" />
          <span>{speechRate === 0.85 ? 'Audio: Normal' : 'Audio: Pelan'}</span>
        </button>
      </div>

      {/* Main Understand Content */}
      <div className="w-full max-w-sm my-auto space-y-4">
        {/* Arabic Word Display Card */}
        <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-sm relative overflow-hidden">
          <div className="absolute top-3 right-3">
            <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold tracking-wider uppercase bg-emerald-50 text-emerald-700 border border-emerald-100">
              {item.wordType}
            </span>
          </div>

          {/* Arabic with Harakat */}
          <div className="my-2">
            <span className="font-arabic text-6xl text-slate-900 font-bold block select-none leading-relaxed">
              {item.arabic}
            </span>
          </div>

          {/* Transliteration */}
          <p className="text-emerald-700 font-semibold text-base tracking-wide">
            {item.transliteration}
          </p>

          {/* Audio Button */}
          <div className="mt-3 flex justify-center">
            <button
              onClick={playWord}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full font-medium text-sm transition-all ${
                isPlayingWord
                  ? 'bg-emerald-600 text-white shadow-md animate-pulse ring-4 ring-emerald-100'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}
            >
              <Volume2 className={`w-4 h-4 ${isPlayingWord ? 'animate-bounce' : ''}`} />
              <span>{isPlayingWord ? 'Mendengarkan...' : 'Dengarkan Audio'}</span>
            </button>
          </div>

          {/* Indonesian Meaning */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <span className="text-xs uppercase font-medium text-slate-400 block mb-1">
              Arti Bahasa Indonesia
            </span>
            <p className="text-xl font-bold text-slate-800">
              {item.meaning}
            </p>
            {item.rootWord && (
              <span className="text-[11px] text-slate-400 mt-1 inline-block">
                Akar kata: <span className="font-arabic font-bold text-slate-600">{item.rootWord}</span>
              </span>
            )}
          </div>
        </div>

        {/* Example Sentence Card */}
        <div className="bg-emerald-900 text-white rounded-3xl p-5 shadow-sm text-left relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-emerald-300 uppercase tracking-wider">
              Contoh Penggunaan Kalimat
            </span>
            <button
              onClick={playExample}
              className="p-1.5 rounded-full bg-emerald-800 hover:bg-emerald-700 text-emerald-200 transition-colors"
              title="Dengarkan Contoh Kalimat"
            >
              <Volume2 className={`w-4 h-4 ${isPlayingExample ? 'animate-pulse text-white' : ''}`} />
            </button>
          </div>

          <p className="font-arabic text-xl font-bold text-emerald-50 leading-loose text-right my-1">
            {item.exampleArabic}
          </p>

          <p className="text-xs text-emerald-200/90 italic font-medium mt-1">
            {item.exampleTransliteration}
          </p>

          <p className="text-xs text-emerald-100 mt-2 pt-2 border-t border-emerald-800/80">
            "{item.exampleMeaning}"
          </p>
        </div>
      </div>

      {/* Action Next */}
      <button
        onClick={onNext}
        className="w-full max-w-sm mt-4 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-[0.98] transition-all"
      >
        <span>Sudah Paham → Uji Ingatan (Recall)</span>
        <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );
};
