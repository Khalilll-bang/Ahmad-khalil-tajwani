import React, { useState } from 'react';
import { Target, CheckCircle2, ChevronRight, Sparkles, Flame, Edit3, X, Check } from 'lucide-react';
import { UserProfile, UserStats } from '../types';

interface DailyGoalCardProps {
  stats: UserStats;
  userProfile?: UserProfile | null;
  onUpdateGoal: (newGoal: number) => void;
  onStartSession?: () => void;
}

export const DailyGoalCard: React.FC<DailyGoalCardProps> = ({
  stats,
  userProfile,
  onUpdateGoal,
  onStartSession,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const currentGoal = userProfile?.dailyGoal || 15;
  const [tempGoal, setTempGoal] = useState(currentGoal);

  const completedCount = stats.todayReviewedCount;
  const progressPercent = Math.min(100, Math.round((completedCount / currentGoal) * 100));
  const isGoalAchieved = completedCount >= currentGoal;
  const remaining = Math.max(0, currentGoal - completedCount);

  const presetGoals = [5, 10, 15, 20, 25, 40];

  const handleSaveGoal = (val: number) => {
    onUpdateGoal(val);
    setIsEditing(false);
  };

  return (
    <div className="bg-[#faf6ef] rounded-3xl border border-[#e6d8c4] p-4 shadow-sm relative overflow-hidden transition-all">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center ${
              isGoalAchieved ? 'bg-amber-100 text-amber-800' : 'bg-[#faeae0] text-terracotta-800'
            }`}
          >
            {isGoalAchieved ? <Sparkles className="w-4 h-4 fill-amber-500" /> : <Target className="w-4 h-4" />}
          </div>
          <div>
            <h3 className="text-xs font-bold text-dune-900 flex items-center gap-1.5">
              <span>Target Kosakata Harian</span>
              <span className="font-arabic text-[11px] text-terracotta-700 font-semibold">
                (الهدف اليومي)
              </span>
            </h3>
            <p className="text-[10px] text-dune-500 font-medium">
              {isGoalAchieved
                ? 'Target hari ini tuntas! Terus asah hafalanmu di padang ilmu.'
                : `Target: ${currentGoal} kosakata per hari`}
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setTempGoal(currentGoal);
            setIsEditing(!isEditing);
          }}
          className="px-2.5 py-1 rounded-xl text-[11px] font-semibold text-terracotta-800 bg-[#faeae0] hover:bg-[#f4d4c0] border border-[#f4d4c0] flex items-center gap-1 transition-colors"
        >
          <Edit3 className="w-3 h-3" />
          <span>{isEditing ? 'Tutup' : 'Ubah Target'}</span>
        </button>
      </div>

      {/* Editing Goal Mode Drawer */}
      {isEditing && (
        <div className="mb-4 p-3.5 bg-[#f4eee2] rounded-2xl border border-[#ddcaa8] animate-fadeIn space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-dune-800">Pilih Jumlah Kosakata / Hari:</span>
            <span className="text-xs font-extrabold text-terracotta-800 bg-[#faeae0] border border-[#f4d4c0] px-2 py-0.5 rounded-lg">
              {tempGoal} Kata
            </span>
          </div>

          {/* Quick Presets */}
          <div className="grid grid-cols-6 gap-1.5">
            {presetGoals.map((val) => (
              <button
                key={val}
                onClick={() => setTempGoal(val)}
                className={`py-1.5 rounded-xl text-xs font-bold transition-all ${
                  tempGoal === val
                    ? 'bg-terracotta-700 text-white shadow-sm ring-2 ring-terracotta-300'
                    : 'bg-[#faf6ef] text-dune-800 border border-[#ddcaa8] hover:border-terracotta-400'
                }`}
              >
                {val}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="range"
              min="3"
              max="50"
              step="1"
              value={tempGoal}
              onChange={(e) => setTempGoal(Number(e.target.value))}
              className="flex-1 accent-terracotta-600 h-1.5 bg-[#ddcaa8] rounded-lg cursor-pointer"
            />
            <button
              onClick={() => handleSaveGoal(tempGoal)}
              className="px-3 py-1.5 bg-terracotta-700 hover:bg-terracotta-800 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-sm"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Simpan</span>
            </button>
          </div>
        </div>
      )}

      {/* Numerical Progress & Status */}
      <div className="flex items-baseline justify-between mb-1.5">
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl font-black text-dune-900 tracking-tight">
            {completedCount}
          </span>
          <span className="text-xs text-dune-400 font-semibold">/ {currentGoal} kata</span>
        </div>

        <div className="flex items-center gap-1.5">
          {isGoalAchieved ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-amber-100 text-amber-900 border border-amber-300">
              <CheckCircle2 className="w-3 h-3 text-amber-600" />
              <span>Tercapai! (Mumtaz)</span>
            </span>
          ) : (
            <span className="text-xs font-extrabold text-terracotta-800 bg-[#faeae0] px-2 py-0.5 rounded-lg border border-[#f4d4c0]">
              {progressPercent}%
            </span>
          )}
        </div>
      </div>

      {/* Progress Bar in Desert Sand & Terracotta */}
      <div className="w-full h-3 bg-[#ebdcc3]/60 rounded-full overflow-hidden p-0.5 border border-[#ddcaa8] mb-2.5">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            isGoalAchieved
              ? 'bg-gradient-to-r from-terracotta-600 to-amber-400 shadow-sm'
              : 'bg-gradient-to-r from-terracotta-700 to-amber-500'
          }`}
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Bottom Motivation & Action */}
      <div className="flex items-center justify-between pt-1 text-[11px]">
        <div className="flex items-center gap-1.5 text-dune-600">
          <Flame className="w-3.5 h-3.5 text-terracotta-600 fill-terracotta-500" />
          <span>
            {isGoalAchieved
              ? 'Luar biasa! Target hari ini terpenuhi.'
              : `Sisa ${remaining} kata lagi untuk mencapai target.`}
          </span>
        </div>

        {onStartSession && !isGoalAchieved && (
          <button
            onClick={onStartSession}
            className="text-xs font-bold text-terracotta-700 hover:text-terracotta-800 flex items-center gap-0.5 hover:underline"
          >
            <span>Mulai</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
