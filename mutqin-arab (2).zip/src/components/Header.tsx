import React from 'react';
import { Flame, LogOut } from 'lucide-react';
import { UserStats, UserProfile } from '../types';
import { AppLogo } from './AppLogo';

interface Props {
  stats: UserStats;
  dueCount: number;
  userProfile?: UserProfile | null;
  onLogout?: () => void;
}

export const Header: React.FC<Props> = ({ stats, dueCount, userProfile, onLogout }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#faf6ef]/95 backdrop-blur-md border-b border-[#e6d8c4] px-4 py-2.5 shadow-xs">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Logo and Brand with Arabic Calligraphy */}
        <AppLogo
          size="md"
          subtext={
            userProfile
              ? `${userProfile.name} • ${userProfile.schoolName}`
              : 'الأَرْبَعِين - SRS Kosakata'
          }
        />

        {/* Stats Pill & Logout */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Due Count Pill */}
          {dueCount > 0 && (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100/90 border border-amber-300 text-amber-900 text-[11px] font-bold animate-pulse">
              <span>{dueCount} Due</span>
            </div>
          )}

          {/* Daily Streak */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#faeae0] border border-[#f4d4c0] text-terracotta-800 text-xs font-bold">
            <Flame className="w-3.5 h-3.5 fill-terracotta-600 text-terracotta-600" />
            <span>{stats.dailyStreak} hari</span>
          </div>

          {/* Logout button */}
          {onLogout && (
            <button
              onClick={() => {
                if (window.confirm('Keluar dari sesi akun ini? Progres belajarmu tetap tersimpan.')) {
                  onLogout();
                }
              }}
              title="Ganti Akun / Keluar"
              className="p-1.5 rounded-xl hover:bg-[#ebdcc3]/60 text-dune-400 hover:text-rose-600 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

