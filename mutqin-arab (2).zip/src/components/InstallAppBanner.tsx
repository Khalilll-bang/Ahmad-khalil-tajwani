import React, { useState, useEffect } from 'react';
import { Smartphone, Download, Check, X, Share2, PlusSquare } from 'lucide-react';

export const InstallAppBanner: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showIosGuide, setShowIosGuide] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isIos, setIsIos] = useState(false);

  useEffect(() => {
    // Check if already in standalone mode (installed)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    if (isStandalone) {
      setIsInstalled(true);
      return;
    }

    // Detect iOS
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isApple = /iphone|ipad|ipod/.test(userAgent);
    setIsIos(isApple);

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handler);

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else if (isIos) {
      setShowIosGuide(true);
    } else {
      // General instructions for Android Chrome / Mobile browser
      alert('Untuk memasang di HP:\n1. Buka menu browser (titik 3 di kanan atas)\n2. Pilih "Install app" atau "Tambahkan ke Layar Utama" (Add to Home Screen)');
    }
  };

  if (isInstalled || isDismissed) return null;

  return (
    <>
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white px-4 py-2.5 rounded-2xl shadow-lg border border-emerald-600/40 mb-4 flex items-center justify-between animate-fadeIn">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center shrink-0 border border-white/20">
            <Smartphone className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <p className="text-xs font-bold leading-tight flex items-center gap-1.5">
              <span>Pasang di Layar HP (Aplikasi Android / Web App)</span>
              <span className="px-1.5 py-0.2 rounded-md bg-emerald-500/30 text-[10px] text-emerald-200 border border-emerald-400/30 font-medium">Instan</span>
            </p>
            <p className="text-[11px] text-emerald-200/90 leading-tight mt-0.5">
              Bisa dibuka offline, layar penuh seperti aplikasi APK tanpa install manual.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleInstallClick}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-white rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Pasang di HP</span>
          </button>
          <button
            onClick={() => setIsDismissed(true)}
            className="p-1 rounded-lg text-emerald-300 hover:bg-white/10 transition-colors"
            title="Tutup"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* iOS Safari Guide Modal */}
      {showIosGuide && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-slate-800 shadow-2xl relative">
            <button
              onClick={() => setShowIosGuide(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="text-center mb-4">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl mx-auto flex items-center justify-center mb-2">
                <Smartphone className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold">Pasang di iPhone / iPad</h3>
            </div>
            <ol className="text-xs space-y-3 text-slate-600 bg-slate-50 p-4 rounded-2xl border border-slate-100 mb-5">
              <li className="flex items-start gap-2">
                <span className="font-bold text-emerald-700 bg-emerald-100 w-5 h-5 rounded-full flex items-center justify-center shrink-0">1</span>
                <span>Tekan tombol <strong>Share / Bagikan</strong> (<Share2 className="w-3.5 h-3.5 inline text-blue-600" />) di Safari.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-emerald-700 bg-emerald-100 w-5 h-5 rounded-full flex items-center justify-center shrink-0">2</span>
                <span>Gulir ke bawah dan pilih <strong>Tambahkan ke Layar Utama</strong> (<PlusSquare className="w-3.5 h-3.5 inline text-slate-700" />).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-emerald-700 bg-emerald-100 w-5 h-5 rounded-full flex items-center justify-center shrink-0">3</span>
                <span>Tekan <strong>Tambah (Add)</strong> di pojok kanan atas.</span>
              </li>
            </ol>
            <button
              onClick={() => setShowIosGuide(false)}
              className="w-full py-2.5 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800"
            >
              Saya Mengerti
            </button>
          </div>
        </div>
      )}
    </>
  );
};
