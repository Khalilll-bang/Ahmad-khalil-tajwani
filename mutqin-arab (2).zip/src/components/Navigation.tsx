import React from 'react';
import { Home, BookOpen, Layers, BarChart3 } from 'lucide-react';

export type NavTab = 'home' | 'vocab' | 'drills' | 'stats';

interface Props {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  dueCount: number;
}

export const Navigation: React.FC<Props> = ({ activeTab, onChangeTab, dueCount }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#faf6ef]/95 backdrop-blur-md border-t border-[#e6d8c4] py-1.5 px-4 shadow-lg">
      <div className="max-w-md mx-auto grid grid-cols-4 gap-1">
        {/* Tab 1: Home / Belajar */}
        <button
          onClick={() => onChangeTab('home')}
          className={`py-1.5 flex flex-col items-center justify-center rounded-2xl transition-all relative ${
            activeTab === 'home'
              ? 'text-terracotta-700 font-extrabold'
              : 'text-dune-400 hover:text-dune-600'
          }`}
        >
          <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-1">Belajar</span>
          {dueCount > 0 && activeTab !== 'home' && (
            <span className="absolute top-1 right-5 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-[#faf6ef]" />
          )}
        </button>

        {/* Tab 2: Bank Kosakata */}
        <button
          onClick={() => onChangeTab('vocab')}
          className={`py-1.5 flex flex-col items-center justify-center rounded-2xl transition-all ${
            activeTab === 'vocab'
              ? 'text-terracotta-700 font-extrabold'
              : 'text-dune-400 hover:text-dune-600'
          }`}
        >
          <BookOpen className={`w-5 h-5 ${activeTab === 'vocab' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-1">Bank Kata</span>
        </button>

        {/* Tab 3: Mode Latihan */}
        <button
          onClick={() => onChangeTab('drills')}
          className={`py-1.5 flex flex-col items-center justify-center rounded-2xl transition-all ${
            activeTab === 'drills'
              ? 'text-terracotta-700 font-extrabold'
              : 'text-dune-400 hover:text-dune-600'
          }`}
        >
          <Layers className={`w-5 h-5 ${activeTab === 'drills' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-1">Latihan</span>
        </button>

        {/* Tab 4: Statistik & SRS */}
        <button
          onClick={() => onChangeTab('stats')}
          className={`py-1.5 flex flex-col items-center justify-center rounded-2xl transition-all ${
            activeTab === 'stats'
              ? 'text-terracotta-700 font-extrabold'
              : 'text-dune-400 hover:text-dune-600'
          }`}
        >
          <BarChart3 className={`w-5 h-5 ${activeTab === 'stats' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-1">Statistik</span>
        </button>
      </div>
    </nav>
  );
};
