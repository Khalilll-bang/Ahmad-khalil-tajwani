import React, { useState } from 'react';
import { VocabularyItem, ConfidenceRating, TestType } from '../types';
import { CycleIntroduction } from './CycleIntroduction';
import { CycleUnderstand } from './CycleUnderstand';
import { CycleRecall } from './CycleRecall';
import { CycleTest } from './CycleTest';
import { CycleConfidence } from './CycleConfidence';
import { CycleScheduleMaster } from './CycleScheduleMaster';
import { SrsEngine } from '../services/srsEngine';
import { StorageService } from '../services/storageService';
import { X, CheckCircle, Award, Sparkles, ChevronRight } from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  queue: VocabularyItem[];
  allVocab: VocabularyItem[];
  onClose: () => void;
  onSessionComplete: () => void;
}

type StepType = 'intro' | 'understand' | 'recall' | 'test' | 'confidence' | 'schedule';

export const StudySessionModal: React.FC<Props> = ({ queue, allVocab, onClose, onSessionComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentStep, setCurrentStep] = useState<StepType>('intro');
  const [testPassed, setTestPassed] = useState(true);
  const [lastRating, setLastRating] = useState<ConfidenceRating>('good');
  const [scheduleData, setScheduleData] = useState<{
    oldItem: VocabularyItem;
    updatedItem: VocabularyItem;
    explanation: string;
    nextDueFormatted: string;
  } | null>(null);

  // Session summary stats
  const [sessionResults, setSessionResults] = useState<{
    correctCount: number;
    againCount: number;
    newMasteredCount: number;
  }>({
    correctCount: 0,
    againCount: 0,
    newMasteredCount: 0,
  });
  const [isDone, setIsDone] = useState(false);

  const currentItem = queue[currentIndex];

  if (!currentItem || isDone) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-3xl p-6 text-center shadow-2xl animate-scaleUp">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
            <Award className="w-9 h-9" />
          </div>

          <h2 className="text-2xl font-extrabold text-slate-900 mb-1">
            Sesi Belajar Selesai!
          </h2>
          <p className="text-xs text-slate-500 mb-6">
            Kosakata telah diproses melalui siklus SRS memori jangka panjang.
          </p>

          <div className="grid grid-cols-3 gap-2.5 mb-6">
            <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-100">
              <span className="text-2xl font-extrabold text-emerald-700 block">
                {queue.length}
              </span>
              <span className="text-[10px] font-semibold text-slate-600">Total Kata</span>
            </div>
            <div className="p-3 bg-blue-50 rounded-2xl border border-blue-100">
              <span className="text-2xl font-extrabold text-blue-700 block">
                {sessionResults.correctCount}
              </span>
              <span className="text-[10px] font-semibold text-slate-600">Tepat Diingat</span>
            </div>
            <div className="p-3 bg-amber-50 rounded-2xl border border-amber-100">
              <span className="text-2xl font-extrabold text-amber-700 block">
                {sessionResults.newMasteredCount}
              </span>
              <span className="text-[10px] font-semibold text-slate-600">Mutqin Baru</span>
            </div>
          </div>

          <button
            onClick={() => {
              onSessionComplete();
              onClose();
            }}
            className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-lg shadow-emerald-600/20 active:scale-98 transition-all"
          >
            Kembali ke Beranda
          </button>
        </div>
      </div>
    );
  }

  // Steps handling
  const handleNextFromIntro = () => setCurrentStep('understand');
  const handleNextFromUnderstand = () => setCurrentStep('recall');
  const handleNextFromRecall = () => setCurrentStep('test');

  const handleTestComplete = (passed: boolean, modeUsed: TestType) => {
    setTestPassed(passed);
    setCurrentStep('confidence');
  };

  const handleConfidenceRating = (rating: ConfidenceRating) => {
    setLastRating(rating);
    const oldItem = { ...currentItem };
    const { updatedItem, explanation, nextDueFormatted } = SrsEngine.processReview(
      currentItem,
      rating,
      Date.now()
    );

    // Persist updated item
    StorageService.updateVocabularyItem(updatedItem);

    // Log review
    StorageService.logReview({
      id: `log-${Date.now()}`,
      vocabId: currentItem.id,
      timestamp: Date.now(),
      rating,
      previousInterval: oldItem.intervalDays,
      newInterval: updatedItem.intervalDays,
      previousMastery: oldItem.masteryLevel,
      newMastery: updatedItem.masteryLevel,
      testPassed,
    });

    // Update session results
    setSessionResults(prev => ({
      correctCount: prev.correctCount + (testPassed && rating !== 'again' ? 1 : 0),
      againCount: prev.againCount + (rating === 'again' ? 1 : 0),
      newMasteredCount:
        prev.newMasteredCount + (updatedItem.status === 'mastered' && oldItem.status !== 'mastered' ? 1 : 0),
    }));

    setScheduleData({
      oldItem,
      updatedItem,
      explanation,
      nextDueFormatted,
    });

    setCurrentStep('schedule');
  };

  const handleContinueNextWord = () => {
    if (currentIndex + 1 < queue.length) {
      setCurrentIndex(prev => prev + 1);
      setCurrentStep('intro');
      setScheduleData(null);
    } else {
      setIsDone(true);
      try {
        confetti({
          particleCount: 80,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch (e) {}
    }
  };

  // Step names for progress header
  const stepTitles = [
    { key: 'intro', label: '1. Intro' },
    { key: 'understand', label: '2. Understand' },
    { key: 'recall', label: '3. Recall' },
    { key: 'test', label: '4. Test' },
    { key: 'confidence', label: '5. Confidence' },
    { key: 'schedule', label: '6-7. SRS' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-scaleUp">
        {/* Top Session Navigation Header */}
        <div className="px-5 pt-4 pb-3 border-b border-slate-100 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-emerald-800">
              Kata {currentIndex + 1} dari {queue.length}
            </span>
            <div className="w-32 h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / queue.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Close / Quit button */}
          <button
            onClick={() => {
              if (window.confirm('Yakin ingin menghentikan sesi belajar ini? Progres kata yang sudah dievaluasi tetap tersimpan.')) {
                onClose();
              }
            }}
            className="p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 7-Step Mini Indicator */}
        <div className="px-5 py-2 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between text-[11px] font-semibold text-slate-400 overflow-x-auto">
          {stepTitles.map((s, i) => {
            const isCurrent =
              s.key === currentStep || (s.key === 'schedule' && currentStep === 'schedule');
            return (
              <span
                key={s.key}
                className={`px-2 py-0.5 rounded-md whitespace-nowrap transition-colors ${
                  isCurrent
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-400'
                }`}
              >
                {s.label}
              </span>
            );
          })}
        </div>

        {/* Modal Body Container */}
        <div className="flex-1 overflow-y-auto">
          {currentStep === 'intro' && (
            <CycleIntroduction item={currentItem} onNext={handleNextFromIntro} />
          )}

          {currentStep === 'understand' && (
            <CycleUnderstand item={currentItem} onNext={handleNextFromUnderstand} />
          )}

          {currentStep === 'recall' && (
            <CycleRecall item={currentItem} onNext={handleNextFromRecall} />
          )}

          {currentStep === 'test' && (
            <CycleTest
              item={currentItem}
              allVocab={allVocab}
              onComplete={handleTestComplete}
            />
          )}

          {currentStep === 'confidence' && (
            <CycleConfidence
              item={currentItem}
              testPassed={testPassed}
              onRate={handleConfidenceRating}
            />
          )}

          {currentStep === 'schedule' && scheduleData && (
            <CycleScheduleMaster
              oldItem={scheduleData.oldItem}
              updatedItem={scheduleData.updatedItem}
              explanation={scheduleData.explanation}
              nextDueFormatted={scheduleData.nextDueFormatted}
              rating={lastRating}
              isSessionFinished={currentIndex + 1 >= queue.length}
              onContinue={handleContinueNextWord}
            />
          )}
        </div>
      </div>
    </div>
  );
};
