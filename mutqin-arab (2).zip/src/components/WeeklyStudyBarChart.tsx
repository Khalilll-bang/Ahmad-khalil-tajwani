import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Cell,
} from 'recharts';
import { BarChart3, TrendingUp } from 'lucide-react';

export interface DailyStudyStat {
  dateKey: string; // YYYY-MM-DD
  dayLabel: string; // Sen, Sel, Rab...
  dateDisplay: string; // 28 Sep
  count: number; // Jumlah kosakata yang dipelajari/direview
  isToday: boolean;
}

interface Props {
  data: DailyStudyStat[];
  dailyGoal: number;
}

export const WeeklyStudyBarChart: React.FC<Props> = ({ data, dailyGoal }) => {
  const total7Days = data.reduce((acc, curr) => acc + curr.count, 0);
  const average7Days = Math.round(total7Days / 7);
  const maxCount = Math.max(...data.map(d => d.count), dailyGoal, 5);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const item: DailyStudyStat = payload[0].payload;
      const isMet = item.count >= dailyGoal;
      return (
        <div className="bg-[#261509]/95 backdrop-blur-sm text-amber-50 px-3 py-2 rounded-xl text-xs shadow-xl border border-[#7c4d28]">
          <div className="flex items-center gap-1.5 font-bold mb-1">
            <span>{item.dayLabel}</span>
            <span className="text-desert-300 font-normal">({item.dateDisplay})</span>
            {item.isToday && (
              <span className="bg-amber-400/20 text-amber-300 text-[10px] px-1 rounded font-semibold border border-amber-400/30">
                Hari ini
              </span>
            )}
          </div>
          <div className="text-amber-300 font-black text-sm">
            {item.count} <span className="text-xs font-normal text-desert-200">kosakata</span>
          </div>
          <div className="text-[10px] mt-0.5 text-desert-300">
            Target: {dailyGoal} kata • {isMet ? '✅ Tercapai' : `Kurang ${Math.max(0, dailyGoal - item.count)}`}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-sm space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#faeae0] text-terracotta-800 flex items-center justify-center">
            <BarChart3 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-dune-900 flex items-center gap-1.5">
              <span>Aktivitas 7 Hari Terakhir</span>
              <span className="text-[10px] font-semibold text-terracotta-800 bg-[#faeae0] border border-[#f4d4c0] px-1.5 py-0.2 rounded-md">
                Grafik Batang
              </span>
            </h3>
            <p className="text-[10px] text-dune-500">
              Jumlah kosakata yang dipelajari & direview per hari
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-xs font-black text-dune-900 block leading-tight">
            {total7Days} <span className="text-[10px] font-normal text-dune-500">kata</span>
          </span>
          <span className="text-[9px] text-terracotta-700 font-bold flex items-center justify-end gap-0.5">
            <TrendingUp className="w-2.5 h-2.5" />
            <span>Rata-rata {average7Days}/hari</span>
          </span>
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="w-full h-44 pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 12, right: 8, left: -24, bottom: 0 }}>
            <XAxis
              dataKey="dayLabel"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: '#7c5a3d', fontWeight: 600 }}
              dy={4}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10, fill: '#a0856c' }}
              allowDecimals={false}
              domain={[0, Math.ceil(maxCount * 1.15)]}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(235, 220, 195, 0.4)', radius: 8 }} />
            
            {/* Target Line Reference in Terracotta */}
            {dailyGoal > 0 && (
              <ReferenceLine
                y={dailyGoal}
                stroke="#b84e23"
                strokeDasharray="3 3"
                strokeWidth={1.5}
                label={{
                  value: `Target: ${dailyGoal}`,
                  position: 'insideTopRight',
                  fill: '#b84e23',
                  fontSize: 9,
                  fontWeight: 'bold',
                }}
              />
            )}

            <Bar dataKey="count" radius={[6, 6, 2, 2]} maxBarSize={32}>
              {data.map((entry) => {
                const reachedGoal = entry.count >= dailyGoal && entry.count > 0;
                let fill = '#ddcaa8'; // Sand grain for 0
                if (entry.count > 0) {
                  fill = reachedGoal ? '#943b19' : '#d97706'; // Terracotta / Desert Amber
                }
                if (entry.isToday) {
                  fill = reachedGoal ? '#7c3013' : '#b45309'; // Rich desert focus for today
                }
                return (
                  <Cell
                    key={`cell-${entry.dateKey}`}
                    fill={fill}
                    className="transition-all hover:opacity-85"
                  />
                );
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Bottom Indicators / Legend */}
      <div className="pt-1 border-t border-[#ebdcc3] flex items-center justify-between text-[10px] text-dune-500">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-terracotta-700 shrink-0" />
            <span>Capai Target ({dailyGoal})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 shrink-0" />
            <span>Belajar</span>
          </div>
        </div>
        <span className="italic text-dune-400 text-[10px]">
          Target harian: <strong>{dailyGoal} kata</strong>
        </span>
      </div>
    </div>
  );
};
