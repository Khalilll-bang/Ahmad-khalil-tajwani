import React, { useState } from 'react';
import { VocabularyItem, TestType } from '../types';
import { CycleTest } from '../components/CycleTest';
import {
  Headphones,
  ListOrdered,
  Shuffle,
  Layers,
  Keyboard,
  ArrowLeft,
  Award,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  vocabList: VocabularyItem[];
}

export const DrillModesScreen: React.FC<Props> = ({ vocabList }) => {
  const [activeDrill, setActiveDrill] = useState<TestType | null>(null);
  const [drillIndex, setDrillIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [drillFinished, setDrillFinished] = useState(false);

  // Drill modes definition with Arabian Desert theming
  const modes: Array<{
    id: TestType;
    title: string;
    description: string;
    icon: React.ReactNode;
    color: string;
  }> = [
    {
      id: 'listening',
      title: 'Uji Mendengarkan (Listening)',
      description: 'Latih telinga membedakan makhraj dan lafal kata Arab dengan audio murni qari.',
      icon: <Headphones className="w-6 h-6 text-amber-800" />,
      color: 'bg-[#faf6ef] border-[#ddcaa8] hover:border-amber-500',
    },
    {
      id: 'sentence_scramble',
      title: 'Susun Kalimat (Sentence Scramble)',
      description: 'Susun potongan kata Arab menjadi contoh kalimat yang runtut dan bermakna.',
      icon: <ListOrdered className="w-6 h-6 text-terracotta-700" />,
      color: 'bg-[#faf6ef] border-[#f4d4c0] hover:border-terracotta-500',
    },
    {
      id: 'matching',
      title: 'Cocokkan Pasangan (Matching)',
      description: 'Uji kecepatan asosiasi antara kosakata Arab dan arti bahasa Indonesia.',
      icon: <Shuffle className="w-6 h-6 text-dune-800" />,
      color: 'bg-[#faf6ef] border-[#e6d8c4] hover:border-dune-500',
    },
    {
      id: 'multiple_choice',
      title: 'Pilihan Ganda Kilat',
      description: 'Pilih arti yang tepat dari beberapa opsi pengecoh kontekstual.',
      icon: <Layers className="w-6 h-6 text-amber-700" />,
      color: 'bg-[#faf6ef] border-amber-300 hover:border-amber-500',
    },
    {
      id: 'typing',
      title: 'Ketik Arti & Ejaan',
      description: 'Perkuat koneksi memori aktif dengan mengetikkan arti atau transliterasi.',
      icon: <Keyboard className="w-6 h-6 text-rose-800" />,
      color: 'bg-[#faf6ef] border-rose-200 hover:border-rose-400',
    },
  ];

  // Select 5 random words for the drill
  const drillItems = React.useMemo(() => {
    return [...vocabList].sort(() => 0.5 - Math.random()).slice(0, 5);
  }, [vocabList, activeDrill]);

  const handleStartDrill = (mode: TestType) => {
    setActiveDrill(mode);
    setDrillIndex(0);
    setScore(0);
    setDrillFinished(false);
  };

  const handleTestStepComplete = (passed: boolean) => {
    if (passed) setScore(prev => prev + 1);

    if (drillIndex + 1 < drillItems.length) {
      setDrillIndex(prev => prev + 1);
    } else {
      setDrillFinished(true);
      try {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      } catch (e) {}
    }
  };

  if (activeDrill) {
    const currentItem = drillItems[drillIndex];

    if (drillFinished || !currentItem) {
      return (
        <div className="pb-24 pt-4 px-4 max-w-md mx-auto text-center space-y-5 animate-scaleUp">
          <div className="p-8 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 border border-amber-300 text-amber-900 flex items-center justify-center mx-auto mb-4">
              <Award className="w-9 h-9" />
            </div>

            <h3 className="text-xl font-extrabold text-dune-900 mb-1">
              Latihan Selesai!
            </h3>
            <p className="text-xs text-dune-500 mb-6">
              Skor Akurasi Drill: <strong className="text-terracotta-700">{score} dari {drillItems.length} Benar</strong>
            </p>

            <div className="flex gap-2">
              <button
                onClick={() => handleStartDrill(activeDrill)}
                className="flex-1 py-3 px-4 rounded-xl border border-[#ddcaa8] font-semibold text-xs text-dune-800 bg-[#f4eee2] hover:bg-[#ebdcc3] flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-4 h-4" /> Ulangi Mode Ini
              </button>
              <button
                onClick={() => setActiveDrill(null)}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-terracotta-700 to-amber-600 hover:from-terracotta-800 hover:to-amber-700 text-white font-semibold text-xs flex items-center justify-center shadow-md transition-all"
              >
                Ganti Mode Latihan
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-4">
        {/* Top Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveDrill(null)}
            className="flex items-center gap-1 text-xs font-semibold text-dune-500 hover:text-dune-900"
          >
            <ArrowLeft className="w-4 h-4" /> Kembali ke Daftar Mode
          </button>
          <span className="text-xs font-bold text-terracotta-800 bg-[#faeae0] border border-[#f4d4c0] px-2 py-0.5 rounded-lg">
            {drillIndex + 1} / {drillItems.length}
          </span>
        </div>

        {/* Test view */}
        <div className="bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-sm overflow-hidden">
          <CycleTest
            key={currentItem.id}
            item={currentItem}
            allVocab={vocabList}
            preferredMode={activeDrill}
            onComplete={(passed) => handleTestStepComplete(passed)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-4 animate-fadeIn">
      <div>
        <h2 className="text-xl font-extrabold text-dune-900 tracking-tight">
          Mode Latihan Khusus
        </h2>
        <p className="text-xs text-dune-500">
          Pilih variasi pengujian untuk melatih aspek tertentu dari memori
        </p>
      </div>

      <div className="space-y-3">
        {modes.map(mode => (
          <button
            key={mode.id}
            onClick={() => handleStartDrill(mode.id)}
            className={`w-full p-4 rounded-3xl border ${mode.color} text-left flex items-start gap-4 shadow-2xs hover:shadow-md transition-all active:scale-[0.99]`}
          >
            <div className="p-3 bg-[#f4eee2] rounded-2xl shadow-xs shrink-0 border border-[#ddcaa8]">
              {mode.icon}
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-bold text-dune-900">{mode.title}</h3>
              <p className="text-xs text-dune-600 mt-1 leading-relaxed">
                {mode.description}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
