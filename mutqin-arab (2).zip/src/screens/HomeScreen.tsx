import React, { useState } from 'react';
import { VocabularyItem, UserStats, UserProfile } from '../types';
import { SrsEngine } from '../services/srsEngine';
import {
  Play,
  Clock,
  AlertTriangle,
  Sparkles,
  Award,
  Volume2,
  ChevronRight,
  Flame,
  CheckCircle2,
  BrainCircuit,
  Star,
  GraduationCap
} from 'lucide-react';
import { audioService } from '../services/audioService';
import { DailyGoalCard } from '../components/DailyGoalCard';

interface Props {
  vocabList: VocabularyItem[];
  stats: UserStats;
  userProfile?: UserProfile | null;
  onUpdateGoal?: (newGoal: number) => void;
  onStartSession: (selectedQueue: VocabularyItem[]) => void;
  onSelectWord: (item: VocabularyItem) => void;
}

export const HomeScreen: React.FC<Props> = ({
  vocabList,
  stats,
  userProfile,
  onUpdateGoal,
  onStartSession,
  onSelectWord,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'due' | 'lapsed' | 'new'>('all');
  const now = Date.now();

  const dueItems = vocabList.filter(v => v.nextReviewDate <= now);
  const lapsedItems = vocabList.filter(v => v.totalLapses > 0);
  const newOrLearningItems = vocabList.filter(v => v.status === 'new' || v.status === 'learning');
  const masteredItems = vocabList.filter(v => v.status === 'mastered');

  // Generate prioritized queue
  let candidateItems = [...vocabList];
  if (filterMode === 'due') {
    candidateItems = dueItems.length > 0 ? dueItems : vocabList;
  } else if (filterMode === 'lapsed') {
    candidateItems = lapsedItems.length > 0 ? lapsedItems : vocabList;
  } else if (filterMode === 'new') {
    candidateItems = newOrLearningItems.length > 0 ? newOrLearningItems : vocabList;
  }

  const prioritizedList = SrsEngine.sortByPriority(candidateItems, now);
  const topQueue = prioritizedList.slice(0, 5);

  const handleStartDefaultSession = () => {
    // Take top 5 or 7 prioritized items
    const sessionItems = prioritizedList.slice(0, Math.min(5, prioritizedList.length));
    onStartSession(sessionItems);
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-5 animate-fadeIn">
      {/* Welcome Greeting Banner in Desert Sandstone */}
      {userProfile && (
        <div className="p-3.5 bg-[#faf6ef] border border-[#e6d8c4] rounded-2xl shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#faeae0] text-terracotta-800 flex items-center justify-center font-bold text-sm">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-dune-400 block font-medium">Ahlan wa Sahlan,</span>
              <span className="text-sm font-bold text-dune-900 leading-tight block">
                {userProfile.name}
              </span>
            </div>
          </div>
          <span className="text-[11px] font-semibold text-terracotta-900 bg-[#faeae0] border border-[#f4d4c0] px-2.5 py-1 rounded-lg">
            {userProfile.schoolName}
          </span>
        </div>
      )}

      {/* Daily Goal Setting & Progress Card */}
      <DailyGoalCard
        stats={stats}
        userProfile={userProfile}
        onUpdateGoal={(newGoal) => onUpdateGoal?.(newGoal)}
        onStartSession={handleStartDefaultSession}
      />

      {/* SRS Philosophy Banner in Arabian Desert Sunset Canyon */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-[#7d3714] via-[#5c2409] to-[#240e04] text-white shadow-lg border border-[#a65626]/40 relative overflow-hidden">
        {/* Desert glow overlay */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10">
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-200 border border-amber-400/30 text-[11px] font-semibold mb-2">
            <BrainCircuit className="w-3.5 h-3.5 text-amber-300" />
            <span>Spaced Repetition System</span>
          </div>

          <h2 className="text-xl font-black text-white tracking-tight leading-snug">
            Belajar → Ingat → Uji → Mutqin
          </h2>
          <p className="text-xs text-desert-100/90 mt-1 leading-relaxed">
            Bukan tentang menghafal cepat lalu lupa, tapi menjaga setiap kosakata meresap ke memori jangka panjang bak mata air di padang pasir.
          </p>

          {/* Quick CTA inside banner in Radiant Desert Amber */}
          <button
            onClick={handleStartDefaultSession}
            className="mt-4 w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-amber-400 hover:brightness-105 text-dune-950 font-black text-sm flex items-center justify-center gap-2 shadow-md shadow-amber-950/40 active:scale-[0.98] transition-all"
          >
            <Play className="w-4 h-4 fill-dune-950 text-dune-950" />
            <span>Mulai Sesi Belajar Prioritas ({topQueue.length} Kata)</span>
          </button>
        </div>
      </div>

      {/* 4 Memory Status Counters in Desert Tones */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* 1. Hampir Lupa */}
        <button
          onClick={() => setFilterMode('due')}
          className={`p-3.5 rounded-2xl border text-left transition-all relative ${
            filterMode === 'due'
              ? 'bg-amber-50/90 border-amber-400 ring-2 ring-amber-200'
              : 'bg-[#faf6ef] border-[#e6d8c4] hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="p-1.5 rounded-xl bg-amber-100 text-amber-900 border border-amber-200/60">
              <Clock className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded-md">
              {dueItems.length}
            </span>
          </div>
          <span className="text-xs font-bold text-dune-900 block">Hampir Lupa</span>
          <span className="text-[10px] text-dune-500">Siap direview hari ini</span>
        </button>

        {/* 2. Sering Salah */}
        <button
          onClick={() => setFilterMode('lapsed')}
          className={`p-3.5 rounded-2xl border text-left transition-all relative ${
            filterMode === 'lapsed'
              ? 'bg-rose-50/90 border-rose-300 ring-2 ring-rose-200'
              : 'bg-[#faf6ef] border-[#e6d8c4] hover:border-rose-200'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="p-1.5 rounded-xl bg-rose-100 text-rose-900 border border-rose-200/60">
              <AlertTriangle className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-rose-900 bg-rose-100/80 px-2 py-0.5 rounded-md">
              {lapsedItems.length}
            </span>
          </div>
          <span className="text-xs font-bold text-dune-900 block">Sering Salah</span>
          <span className="text-[10px] text-dune-500">Perlu penguatan ekstra</span>
        </button>

        {/* 3. Baru Dipelajari */}
        <button
          onClick={() => setFilterMode('new')}
          className={`p-3.5 rounded-2xl border text-left transition-all relative ${
            filterMode === 'new'
              ? 'bg-[#faeae0] border-terracotta-400 ring-2 ring-terracotta-200'
              : 'bg-[#faf6ef] border-[#e6d8c4] hover:border-terracotta-300'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="p-1.5 rounded-xl bg-[#ebdcc3] text-terracotta-900 border border-[#ddcaa8]">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-terracotta-900 bg-[#faeae0] px-2 py-0.5 rounded-md">
              {newOrLearningItems.length}
            </span>
          </div>
          <span className="text-xs font-bold text-dune-900 block">Baru Dipelajari</span>
          <span className="text-[10px] text-dune-500">Tahap pemahaman awal</span>
        </button>

        {/* 4. Sudah Mutqin */}
        <div className="p-3.5 rounded-2xl border bg-[#faf6ef] border-[#e6d8c4] text-left">
          <div className="flex items-center justify-between mb-1">
            <span className="p-1.5 rounded-xl bg-amber-100 text-amber-900 border border-amber-300/60">
              <Award className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded-md">
              {masteredItems.length}
            </span>
          </div>
          <span className="text-xs font-bold text-dune-900 block">Sudah Mutqin</span>
          <span className="text-[10px] text-dune-500">Memori jangka panjang</span>
        </div>
      </div>

      {/* Priority Queue Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-extrabold text-dune-900">
              Antrean Prioritas SRS
            </h3>
            <p className="text-[11px] text-dune-500">
              Diurutkan otomatis: hampir lupa, sering salah, & komunikasi penting
            </p>
          </div>

          {filterMode !== 'all' && (
            <button
              onClick={() => setFilterMode('all')}
              className="text-xs font-semibold text-terracotta-700 hover:text-terracotta-900 hover:underline"
            >
              Reset Filter
            </button>
          )}
        </div>

        {/* List of top prioritized words in Desert Parchment */}
        <div className="space-y-2">
          {topQueue.map((item, index) => {
            const isDue = item.nextReviewDate <= now;
            const hasLapse = item.totalLapses > 0;
            const dueFormatted = SrsEngine.formatDueTime(item.nextReviewDate, now);

            return (
              <div
                key={item.id}
                onClick={() => onSelectWord(item)}
                className="p-3.5 bg-[#faf6ef] border border-[#e6d8c4] hover:border-terracotta-400 rounded-2xl shadow-xs flex items-center justify-between gap-3 cursor-pointer active:scale-[0.99] transition-all"
              >
                {/* Left: Priority Badge & Details */}
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-[#ebdcc3] text-dune-800 text-xs font-bold flex items-center justify-center shrink-0">
                    {index + 1}
                  </span>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-dune-950">{item.meaning}</span>
                      {isDue && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                          Due
                        </span>
                      )}
                      {hasLapse && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-900 border border-rose-200">
                          {item.totalLapses}x Salah
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-dune-400 mt-0.5">
                      <span>{item.category}</span>
                      <span>•</span>
                      <span className="text-terracotta-700 font-medium">{dueFormatted}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Large Arabic text & quick play */}
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-arabic text-2xl font-bold text-dune-950 select-none">
                    {item.arabic}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      audioService.speak(item.arabic);
                    }}
                    className="p-2 rounded-xl bg-[#ebdcc3]/60 hover:bg-[#faeae0] text-dune-700 hover:text-terracotta-800 transition-colors"
                    title="Dengar Audio"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Progress Card */}
      <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-dune-800">Akurasi Retensi Memori</span>
          <span className="text-xs font-extrabold text-terracotta-800">
            {stats.retentionRatePercent}% Retensi
          </span>
        </div>
        <div className="w-full h-2 bg-[#ebdcc3]/60 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-terracotta-700 to-amber-500 rounded-full transition-all duration-500"
            style={{ width: `${stats.retentionRatePercent}%` }}
          />
        </div>
        <p className="text-[11px] text-dune-500 mt-2">
          {stats.todayReviewedCount} ulasan berhasil diselesaikan hari ini. Pertahankan streak belajarmu!
        </p>
      </div>
    </div>
  );
};
