import React, { useState } from 'react';
import { UserProfile } from '../types';
import {
  GraduationCap,
  User,
  School,
  ArrowRight,
  Sparkles,
  BookOpen,
  Brain,
  ShieldCheck,
  CheckCircle2,
  Target
} from 'lucide-react';
import { AppLogo } from '../components/AppLogo';

interface Props {
  onLoginSuccess: (profile: UserProfile) => void;
}

export const LoginScreen: React.FC<Props> = ({ onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [schoolName, setSchoolName] = useState('');
  const [dailyGoal, setDailyGoal] = useState<number>(15);
  const [activeSlide, setActiveSlide] = useState<number>(0);
  const [errorMsg, setErrorMsg] = useState('');

  const slides = [
    {
      title: 'Sistem Belajar Al-Arba\'in 40 (الأَرْبَعِين)',
      subtitle: 'Dirancang dengan metode repetisi terprogram untuk menguasai kosakata inti dan mencapai derajat mutqin.',
      icon: <Brain className="w-8 h-8 text-amber-300" />,
      tag: 'SRS Algorithm',
    },
    {
      title: 'Suara & Uji Pemahaman',
      subtitle: 'Didukung audio pelafalan murni bahasa Arab berwibawa, latihan listening, susun kata, dan kuis pilihan ganda.',
      icon: <BookOpen className="w-8 h-8 text-amber-400" />,
      tag: '7 Siklus Belajar',
    },
    {
      title: 'Target Harian (الهدف اليومي)',
      subtitle: 'Atur target belajar harian sesuai kemampuanmu untuk menjaga istiqomah dan streak setiap hari di padang ilmu.',
      icon: <Target className="w-8 h-8 text-terracotta-400" />,
      tag: 'Daily Goal',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Silakan masukkan nama lengkap atau nama panggilanmu.');
      return;
    }
    if (!schoolName.trim()) {
      setErrorMsg('Silakan masukkan nama sekolah, pesantren, atau kampusmu.');
      return;
    }

    const profile: UserProfile = {
      name: name.trim(),
      schoolName: schoolName.trim(),
      isLoggedIn: true,
      loginDate: new Date().toISOString(),
      dailyGoal: dailyGoal || 15,
      voiceGender: 'male', // Default suara laki-laki khas Arab fasikh
    };

    onLoginSuccess(profile);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#4d260f] via-[#331808] to-[#1a0a03] text-white flex flex-col justify-between p-4 sm:p-6 animate-fadeIn relative overflow-hidden">
      {/* Subtle desert dune decorative glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header & Branding */}
      <div className="max-w-md w-full mx-auto pt-4 text-center space-y-3 relative z-10">
        {/* App Logo Emblem */}
        <div className="flex justify-center">
          <AppLogo
            size="lg"
            showText={false}
          />
        </div>

        <div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span>Al-Arba'in 40</span>
            <span className="font-arabic text-lg font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-sm">
              الأَرْبَعِين ٤٠
            </span>
          </h1>
          <p className="text-xs text-desert-200/90 mt-1">
            Sistem Repetisi Terjadwal untuk Kosakata Bahasa Arab
          </p>
        </div>
      </div>

      {/* Interactive Feature Slider with Desert Styling */}
      <div className="max-w-md w-full mx-auto my-auto py-3 relative z-10">
        <div className="p-5 bg-[#2a1408]/60 backdrop-blur-md rounded-3xl border border-[#d49957]/30 shadow-2xl relative overflow-hidden transition-all duration-300">
          <div className="flex items-center justify-between mb-3">
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-400/20 text-amber-200 border border-amber-400/40">
              {slides[activeSlide].tag}
            </span>
            <div className="p-2 rounded-2xl bg-amber-950/40 border border-amber-500/30">
              {slides[activeSlide].icon}
            </div>
          </div>

          <h3 className="text-lg font-bold text-amber-100 mb-1.5 leading-snug">
            {slides[activeSlide].title}
          </h3>
          <p className="text-xs text-desert-200/85 leading-relaxed min-h-[40px]">
            {slides[activeSlide].subtitle}
          </p>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-1.5 mt-4">
            {slides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setActiveSlide(idx)}
                className={`h-1.5 rounded-full transition-all ${
                  activeSlide === idx
                    ? 'w-6 bg-amber-400 shadow-[0_0_8px_#fbbf24]'
                    : 'w-2 bg-white/30 hover:bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Login Form Sheet in Desert Sandstone Parchment */}
        <div className="mt-4 p-5 sm:p-6 bg-[#faf6ef] text-dune-900 rounded-3xl shadow-2xl border border-[#e4d3bc]">
          <div className="mb-4">
            <h2 className="text-base font-extrabold text-dune-900">
              Masuk & Mulai Belajar
            </h2>
            <p className="text-xs text-dune-600 mt-0.5">
              Masukkan identitasmu untuk menyimpan progres & kurva ingatan
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Nama Field */}
            <div>
              <label className="block text-xs font-bold text-dune-800 mb-1.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-terracotta-700" />
                <span>Nama Lengkap / Panggilan</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrorMsg('');
                }}
                placeholder="Contoh: Ahmad Khalil"
                className="w-full py-2.5 px-3.5 rounded-2xl bg-[#f4eee2] border border-[#ddcaa8] text-sm text-dune-900 focus:outline-none focus:ring-2 focus:ring-terracotta-500/30 focus:border-terracotta-600 focus:bg-white transition-all placeholder:text-dune-400"
              />
            </div>

            {/* Nama Sekolah Field */}
            <div>
              <label className="block text-xs font-bold text-dune-800 mb-1.5 flex items-center gap-1.5">
                <School className="w-3.5 h-3.5 text-terracotta-700" />
                <span>Nama Sekolah / Pesantren / Kampus</span>
              </label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => {
                  setSchoolName(e.target.value);
                  setErrorMsg('');
                }}
                placeholder="Contoh: MAN 1 Mataram / UIN Mataram"
                className="w-full py-2.5 px-3.5 rounded-2xl bg-[#f4eee2] border border-[#ddcaa8] text-sm text-dune-900 focus:outline-none focus:ring-2 focus:ring-terracotta-500/30 focus:border-terracotta-600 focus:bg-white transition-all placeholder:text-dune-400"
              />
            </div>

            {/* Target Harian Kosakata Field */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-dune-800 flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 text-terracotta-700" />
                  <span>Target Harian (Kata/Hari)</span>
                </label>
                <span className="text-xs font-black text-terracotta-800 bg-[#faeae0] border border-[#f4d4c0] px-2 py-0.5 rounded-lg">
                  {dailyGoal} Kata
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[5, 10, 15, 20].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setDailyGoal(num)}
                    className={`py-1.5 rounded-xl text-xs font-bold transition-all ${
                      dailyGoal === num
                        ? 'bg-terracotta-700 text-white shadow-sm ring-2 ring-terracotta-300'
                        : 'bg-[#f0e6d6] text-dune-800 hover:bg-[#ebdcc3] border border-[#ddcca8]'
                    }`}
                  >
                    {num} Kata
                  </button>
                ))}
              </div>
            </div>

            {/* Error banner */}
            {errorMsg && (
              <p className="text-xs text-rose-700 bg-rose-50 border border-rose-200 p-2.5 rounded-xl font-medium">
                {errorMsg}
              </p>
            )}

            {/* Submit button in Desert Terracotta & Amber */}
            <button
              type="submit"
              className="w-full mt-2 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-terracotta-700 via-terracotta-600 to-amber-600 hover:from-terracotta-800 hover:to-amber-700 active:scale-[0.98] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-terracotta-900/25 transition-all"
            >
              <span>Masuk ke Aplikasi</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-3.5 pt-3 border-t border-[#ebdcc3] flex items-center justify-center gap-1.5 text-[11px] text-dune-500 text-center">
            <ShieldCheck className="w-3.5 h-3.5 text-terracotta-700" />
            <span>Data tersimpan otomatis di perangkatmu (Offline Ready)</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="max-w-md w-full mx-auto pb-2 text-center text-[11px] text-desert-300/70 relative z-10">
        Mutqin Arab • Learn → Recall → Review → Master
      </div>
    </div>
  );
};
