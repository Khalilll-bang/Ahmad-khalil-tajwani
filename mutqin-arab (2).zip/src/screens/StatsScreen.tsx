import React, { useState, useMemo } from 'react';
import { UserStats, VocabularyItem, UserProfile } from '../types';
import {
  BarChart3,
  TrendingUp,
  Brain,
  Award,
  RefreshCw,
  Flame,
  CheckCircle,
  Clock,
  Sparkles,
  GraduationCap,
  Target,
  Check,
  Calendar,
  School,
  Volume2,
  Mic,
  Play
} from 'lucide-react';
import { StorageService } from '../services/storageService';
import { audioService } from '../services/audioService';
import { WeeklyStudyBarChart, DailyStudyStat } from '../components/WeeklyStudyBarChart';

interface Props {
  stats: UserStats;
  vocabList: VocabularyItem[];
  userProfile?: UserProfile | null;
  onUpdateGoal?: (newGoal: number) => void;
  onUpdateVoice?: (voice: 'male' | 'female') => void;
  onRefresh: () => void;
}

export const StatsScreen: React.FC<Props> = ({
  stats,
  vocabList,
  userProfile,
  onUpdateGoal,
  onUpdateVoice,
  onRefresh,
}) => {
  const currentGoal = userProfile?.dailyGoal || 15;
  const currentVoice = userProfile?.voiceGender || 'male';
  const [selectedGoal, setSelectedGoal] = useState<number>(currentGoal);
  const [selectedVoice, setSelectedVoice] = useState<'male' | 'female'>(currentVoice);
  const [isSavedNotice, setIsSavedNotice] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const masteredCount = vocabList.filter(v => v.status === 'mastered').length;
  const reviewingCount = vocabList.filter(v => v.status === 'reviewing').length;
  const learningCount = vocabList.filter(v => v.status === 'learning').length;
  const newCount = vocabList.filter(v => v.status === 'new').length;

  const presetGoals = [5, 10, 15, 20, 25, 40];

  // Calculate 7-day study counts from review logs & current session
  const weeklyStudyData: DailyStudyStat[] = useMemo(() => {
    const logs = StorageService.getLogs();
    const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
    const monthNames = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'
    ];

    const result: DailyStudyStat[] = [];
    const today = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const dateKey = `${year}-${month}-${day}`;

      const dayLabel = dayNames[d.getDay()];
      const dateDisplay = `${d.getDate()} ${monthNames[d.getMonth()]}`;
      const isToday = i === 0;

      // Filter logs for this specific calendar day
      const dayLogs = logs.filter(log => {
        const logDate = new Date(log.timestamp);
        const lYear = logDate.getFullYear();
        const lMonth = String(logDate.getMonth() + 1).padStart(2, '0');
        const lDay = String(logDate.getDate()).padStart(2, '0');
        return `${lYear}-${lMonth}-${lDay}` === dateKey;
      });

      // Count unique vocab reviewed or total review actions on that day
      let count = dayLogs.length;

      // If it's today and todayReviewedCount from stats is higher (e.g. current session before reload)
      if (isToday && stats.todayReviewedCount > count) {
        count = stats.todayReviewedCount;
      }

      result.push({
        dateKey,
        dayLabel,
        dateDisplay,
        count,
        isToday,
      });
    }

    return result;
  }, [stats.todayReviewedCount]);

  const handleSelectGoal = (val: number) => {
    setSelectedGoal(val);
    onUpdateGoal?.(val);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2500);
  };

  const handleSelectVoice = (v: 'male' | 'female') => {
    setSelectedVoice(v);
    onUpdateVoice?.(v);
    handlePlayVoiceSample(v);
  };

  const handlePlayVoiceSample = (v: 'male' | 'female' = selectedVoice) => {
    setIsPlayingAudio(true);
    audioService.speak('شُكْرًا جَزِيلًا، مَرْحَبًا بِكُمْ فِي الْأَرْبَعِين', {
      voice: v,
      onEnd: () => setIsPlayingAudio(false),
      onError: () => setIsPlayingAudio(false),
    });
  };

  const handleReset = () => {
    if (window.confirm('Reset semua progres belajar kembali ke awal? Tindakan ini tidak dapat dibatalkan.')) {
      StorageService.resetProgress();
      onRefresh();
    }
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-4 animate-fadeIn">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-dune-900 tracking-tight">
            Profil & Statistik Belajar
          </h2>
          <p className="text-xs text-dune-500">
            {userProfile ? `Pelajar: ${userProfile.name}` : 'Analisis penguasaan memori jangka panjang'}
          </p>
        </div>
        {userProfile && (
          <div className="w-9 h-9 rounded-2xl bg-[#faeae0] text-terracotta-800 flex items-center justify-center border border-[#f4d4c0]">
            <GraduationCap className="w-5 h-5" />
          </div>
        )}
      </div>

      {/* Profil Pelajar Card in Sandstone Parchment */}
      {userProfile && (
        <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-desert-950 via-desert-900 to-terracotta-700 text-amber-300 flex items-center justify-center font-bold text-lg shadow-sm border border-amber-400/40">
              <span className="font-arabic text-xl">٤٠</span>
            </div>
            <div>
              <span className="text-sm font-black text-dune-900 block leading-tight">
                {userProfile.name}
              </span>
              <span className="text-xs text-terracotta-700 font-semibold flex items-center gap-1 mt-0.5">
                <School className="w-3.5 h-3.5 inline text-terracotta-600" />
                <span>{userProfile.schoolName}</span>
              </span>
            </div>
          </div>
          <span className="text-[11px] font-bold px-2.5 py-1 rounded-xl bg-[#faeae0] text-terracotta-800 border border-[#f4d4c0]">
            Al-Arba'in 40
          </span>
        </div>
      )}

      {/* Profil & Daily Goal Setting Card */}
      <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-sm space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#faeae0] text-terracotta-800 flex items-center justify-center">
              <Target className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-dune-900 flex items-center gap-1.5">
                <span>Pengaturan Target Harian (Daily Goal)</span>
                <span className="font-arabic text-[11px] text-terracotta-700 font-semibold">
                  الهدف اليومي
                </span>
              </h3>
              <p className="text-[10px] text-dune-500">
                Tentukan target jumlah kosakata yang ingin diulang/dipelajari tiap hari
              </p>
            </div>
          </div>

          <span className="text-xs font-black text-terracotta-800 bg-[#faeae0] border border-[#f4d4c0] px-2.5 py-1 rounded-xl">
            {selectedGoal} Kata / Hari
          </span>
        </div>

        {/* Quick Goal Presets */}
        <div>
          <span className="text-[11px] font-semibold text-dune-600 block mb-1.5">
            Pilih Target Cepat:
          </span>
          <div className="grid grid-cols-6 gap-1.5">
            {presetGoals.map((val) => (
              <button
                key={val}
                onClick={() => handleSelectGoal(val)}
                className={`py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedGoal === val
                    ? 'bg-terracotta-700 text-white shadow-sm ring-2 ring-terracotta-300 scale-102'
                    : 'bg-[#f4eee2] text-dune-800 border border-[#ddcaa8] hover:border-terracotta-300'
                }`}
              >
                {val}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Range Slider */}
        <div className="space-y-1 pt-1">
          <div className="flex items-center justify-between text-[11px] text-dune-500">
            <span>Sesuaikan (3 - 50 kata):</span>
            <span className="font-bold text-dune-800">{selectedGoal} kosakata</span>
          </div>
          <input
            type="range"
            min="3"
            max="50"
            step="1"
            value={selectedGoal}
            onChange={(e) => handleSelectGoal(Number(e.target.value))}
            className="w-full accent-terracotta-600 h-1.5 bg-[#ddcaa8] rounded-lg cursor-pointer"
          />
        </div>

        {/* Confirmation banner */}
        {isSavedNotice && (
          <div className="p-2 bg-[#faeae0] border border-[#f4d4c0] rounded-xl text-[11px] font-semibold text-terracotta-900 flex items-center gap-1.5 animate-fadeIn">
            <Check className="w-3.5 h-3.5 text-terracotta-700" />
            <span>Target harian berhasil disimpan dan tampil di layar Home!</span>
          </div>
        )}

        {/* Projection info */}
        <div className="p-2.5 bg-[#f4eee2] border border-[#ddcaa8] rounded-2xl flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-1.5 text-dune-600">
            <Calendar className="w-3.5 h-3.5 text-terracotta-700" />
            <span>Estimasi 30 Hari:</span>
          </div>
          <span className="font-bold text-terracotta-800">
            ~{selectedGoal * 30} kosakata mutqin
          </span>
        </div>
      </div>

      {/* Pengaturan Karakter Suara Pelafalan Arab */}
      <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 border border-amber-300 flex items-center justify-center">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-dune-900 flex items-center gap-1.5">
                <span>Karakter Suara Audio (الصوت)</span>
                <span className="font-arabic text-[11px] text-amber-700 font-semibold">
                  (صوت رجالي)
                </span>
              </h3>
              <p className="text-[10px] text-dune-500">
                Pilih jenis timbre vokal pelafalan kosakata
              </p>
            </div>
          </div>

          <button
            onClick={() => handlePlayVoiceSample(selectedVoice)}
            disabled={isPlayingAudio}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
              isPlayingAudio
                ? 'bg-amber-500 text-white animate-pulse'
                : 'bg-amber-100/80 text-amber-900 hover:bg-amber-200 border border-amber-300'
            }`}
          >
            <Play className="w-3 h-3 fill-current" />
            <span>{isPlayingAudio ? 'Memutar...' : 'Tes Suara'}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {/* Suara Pria Khas Arab */}
          <button
            onClick={() => handleSelectVoice('male')}
            className={`p-3 rounded-2xl border text-left transition-all relative ${
              selectedVoice === 'male'
                ? 'border-terracotta-600 bg-[#faeae0] ring-2 ring-terracotta-200 shadow-xs'
                : 'border-[#ddcaa8] bg-[#f4eee2] hover:border-terracotta-300'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-dune-900 flex items-center gap-1">
                <span>Pria Khas Arab</span>
                <span className="text-[10px] bg-amber-200 text-amber-950 px-1 rounded font-black border border-amber-300/80">
                  Fasikh
                </span>
              </span>
              {selectedVoice === 'male' && <Check className="w-4 h-4 text-terracotta-700" />}
            </div>
            <p className="text-[10px] text-dune-500 leading-tight">
              Karakter vokal berwibawa, tajwid mantap, & resonansi dada maskulin khas qari/penutur Arab.
            </p>
          </button>

          {/* Suara Wanita Standar */}
          <button
            onClick={() => handleSelectVoice('female')}
            className={`p-3 rounded-2xl border text-left transition-all relative ${
              selectedVoice === 'female'
                ? 'border-terracotta-600 bg-[#faeae0] ring-2 ring-terracotta-200 shadow-xs'
                : 'border-[#ddcaa8] bg-[#f4eee2] hover:border-terracotta-300'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-dune-900">Wanita Standar</span>
              {selectedVoice === 'female' && <Check className="w-4 h-4 text-terracotta-700" />}
            </div>
            <p className="text-[10px] text-dune-500 leading-tight">
              Pelafalan jernih dengan nada feminin standar kamus modern.
            </p>
          </button>
        </div>
      </div>

      {/* Main KPI Card in Arabian Desert Night Sky */}
      <div className="p-5 bg-gradient-to-br from-[#4d240d] via-[#331808] to-[#1a0a03] text-white rounded-3xl shadow-lg border border-[#80421d]/40 relative overflow-hidden">
        {/* Subtle Desert Night Star Dust */}
        <div className="absolute top-0 right-0 w-28 h-28 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="flex items-center justify-between mb-4 relative z-10">
          <span className="text-xs font-semibold text-desert-200">Indeks Retensi Memori</span>
          <span className="p-1.5 rounded-xl bg-white/10 text-amber-300 border border-white/10">
            <Brain className="w-4 h-4" />
          </span>
        </div>

        <div className="flex items-baseline gap-2 relative z-10">
          <span className="text-4xl font-black text-white">{stats.retentionRatePercent}%</span>
          <span className="text-xs text-amber-300 font-medium">akurasi retensi</span>
        </div>

        <p className="text-xs text-desert-100/80 mt-2 leading-relaxed relative z-10">
          Semakin tinggi nilai retensi, semakin kuat kosakata tersimpan melawan kurva lupa (forgetting curve) di padang ilmu.
        </p>
      </div>

      {/* 7-Day Study Bar Chart Visualization */}
      <WeeklyStudyBarChart data={weeklyStudyData} dailyGoal={selectedGoal} />

      {/* 4 Stats Grid in Desert Sandstone */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-2xl">
          <div className="flex items-center gap-2 text-terracotta-700 mb-1">
            <Flame className="w-4 h-4 fill-terracotta-600" />
            <span className="text-xs font-semibold text-dune-500">Streak Harian</span>
          </div>
          <span className="text-2xl font-black text-dune-900">{stats.dailyStreak} Hari</span>
          <span className="text-[10px] text-dune-400 block mt-0.5">Konsistensi belajar</span>
        </div>

        <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-2xl">
          <div className="flex items-center gap-2 text-amber-600 mb-1">
            <Award className="w-4 h-4" />
            <span className="text-xs font-semibold text-dune-500">Kata Mutqin</span>
          </div>
          <span className="text-2xl font-black text-dune-900">{masteredCount}</span>
          <span className="text-[10px] text-dune-400 block mt-0.5">Memori jangka panjang</span>
        </div>

        <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-2xl">
          <div className="flex items-center gap-2 text-terracotta-800 mb-1">
            <TrendingUp className="w-4 h-4" />
            <span className="text-xs font-semibold text-dune-500">Total Ulasan</span>
          </div>
          <span className="text-2xl font-black text-dune-900">{stats.totalReviewsEver}x</span>
          <span className="text-[10px] text-dune-400 block mt-0.5">Siklus repetisi dijalani</span>
        </div>

        <div className="p-4 bg-[#faf6ef] border border-[#e6d8c4] rounded-2xl">
          <div className="flex items-center gap-2 text-amber-700 mb-1">
            <Clock className="w-4 h-4" />
            <span className="text-xs font-semibold text-dune-500">Review Hari Ini</span>
          </div>
          <span className="text-2xl font-black text-dune-900">{stats.todayReviewedCount}</span>
          <span className="text-[10px] text-dune-400 block mt-0.5">Kosakata hari ini</span>
        </div>
      </div>

      {/* Memory Stage Breakdown Bar in Desert Palette */}
      <div className="p-5 bg-[#faf6ef] border border-[#e6d8c4] rounded-3xl space-y-3">
        <h3 className="text-xs font-bold text-dune-900 uppercase tracking-wider">
          Distribusi Tahapan Memori ({vocabList.length} Total)
        </h3>

        {/* Stacked bar */}
        <div className="h-3 w-full bg-[#ebdcc3]/60 rounded-full overflow-hidden flex border border-[#ddcaa8]">
          <div
            style={{ width: `${(masteredCount / vocabList.length) * 100}%` }}
            className="bg-amber-500 transition-all"
            title="Mutqin"
          />
          <div
            style={{ width: `${(reviewingCount / vocabList.length) * 100}%` }}
            className="bg-terracotta-600 transition-all"
            title="Review"
          />
          <div
            style={{ width: `${(learningCount / vocabList.length) * 100}%` }}
            className="bg-[#caa576] transition-all"
            title="Belajar"
          />
          <div
            style={{ width: `${(newCount / vocabList.length) * 100}%` }}
            className="bg-[#e6d6c2] transition-all"
            title="Baru"
          />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 gap-2 text-xs pt-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
            <span className="text-dune-700">Mutqin: <strong>{masteredCount}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-terracotta-600 shrink-0" />
            <span className="text-dune-700">Review: <strong>{reviewingCount}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#caa576] shrink-0" />
            <span className="text-dune-700">Belajar: <strong>{learningCount}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#e6d6c2] shrink-0" />
            <span className="text-dune-700">Baru: <strong>{newCount}</strong></span>
          </div>
        </div>
      </div>

      {/* Reset Progress Section */}
      <div className="p-4 bg-[#f4eee2] border border-[#ddcaa8] rounded-2xl flex items-center justify-between text-xs">
        <div>
          <span className="font-bold text-dune-900 block">Reset Progres SRS</span>
          <span className="text-dune-500 text-[11px]">Kembalikan semua riwayat dan level</span>
        </div>
        <button
          onClick={handleReset}
          className="px-3 py-1.5 rounded-xl border border-[#ddcaa8] text-rose-700 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1 transition-colors bg-[#faf6ef]"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>
    </div>
  );
          <span className="text-2xl font-black text-slate-900">{masteredCount}</span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Memori jangka panjang</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl">
          <div className="flex items-center gap-2 text-blue-600 mb-1">
            <TrendingUp className="w-4 h-4" />
            <span className="text-xs font-semibold text-slate-500">Total Ulasan</span>
          </div>
          <span className="text-2xl font-black text-slate-900">{stats.totalReviewsEver}x</span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Siklus repetisi dijalani</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl">
          <div className="flex items-center gap-2 text-purple-600 mb-1">
            <Clock className="w-4 h-4" />
            <span className="text-xs font-semibold text-slate-500">Review Hari Ini</span>
          </div>
          <span className="text-2xl font-black text-slate-900">{stats.todayReviewedCount}</span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Kosakata hari ini</span>
        </div>
      </div>

      {/* Memory Stage Breakdown Bar */}
      <div className="p-5 bg-white border border-slate-200 rounded-3xl space-y-3">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
          Distribusi Tahapan Memori ({vocabList.length} Total)
        </h3>

        {/* Stacked bar */}
        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex">
          <div
            style={{ width: `${(masteredCount / vocabList.length) * 100}%` }}
            className="bg-emerald-500 transition-all"
            title="Mutqin"
          />
          <div
            style={{ width: `${(reviewingCount / vocabList.length) * 100}%` }}
            className="bg-blue-500 transition-all"
            title="Review"
          />
          <div
            style={{ width: `${(learningCount / vocabList.length) * 100}%` }}
            className="bg-amber-400 transition-all"
            title="Belajar"
          />
          <div
            style={{ width: `${(newCount / vocabList.length) * 100}%` }}
            className="bg-slate-300 transition-all"
            title="Baru"
          />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 gap-2 text-xs pt-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
            <span className="text-slate-600">Mutqin: <strong>{masteredCount}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0" />
            <span className="text-slate-600">Review: <strong>{reviewingCount}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0" />
            <span className="text-slate-600">Belajar: <strong>{learningCount}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-300 shrink-0" />
            <span className="text-slate-600">Baru: <strong>{newCount}</strong></span>
          </div>
        </div>
      </div>

      {/* Reset Progress Section */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between text-xs">
        <div>
          <span className="font-bold text-slate-800 block">Reset Progres SRS</span>
          <span className="text-slate-500 text-[11px]">Kembalikan semua riwayat dan level</span>
        </div>
        <button
          onClick={handleReset}
          className="px-3 py-1.5 rounded-xl border border-slate-300 text-rose-600 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>
    </div>
  );
};
