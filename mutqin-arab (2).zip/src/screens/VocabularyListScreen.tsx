import React, { useState, useMemo } from 'react';
import { VocabularyItem } from '../types';
import {
  Search,
  Filter,
  Volume2,
  Star,
  Clock,
  Sparkles,
  Award,
  AlertTriangle,
  Play,
  X,
  BookOpen
} from 'lucide-react';
import { audioService } from '../services/audioService';
import { SrsEngine } from '../services/srsEngine';

interface Props {
  vocabList: VocabularyItem[];
  onStartSingleWordSession: (item: VocabularyItem) => void;
}

export const VocabularyListScreen: React.FC<Props> = ({ vocabList, onStartSingleWordSession }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [activeItem, setActiveItem] = useState<VocabularyItem | null>(null);

  const now = Date.now();

  const categories = useMemo(() => {
    const set = new Set(vocabList.map(v => v.category));
    return ['all', ...Array.from(set)];
  }, [vocabList]);

  const filteredList = useMemo(() => {
    return vocabList.filter(item => {
      // Search filter
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        item.meaning.toLowerCase().includes(q) ||
        item.transliteration.toLowerCase().includes(q) ||
        item.arabic.includes(q) ||
        item.arabicClean.includes(q);

      // Category filter
      const matchCat = selectedCategory === 'all' || item.category === selectedCategory;

      // Status filter
      let matchStatus = true;
      if (selectedStatus === 'due') {
        matchStatus = item.nextReviewDate <= now;
      } else if (selectedStatus === 'lapsed') {
        matchStatus = item.totalLapses > 0;
      } else if (selectedStatus === 'learning') {
        matchStatus = item.status === 'learning' || item.status === 'new';
      } else if (selectedStatus === 'mastered') {
        matchStatus = item.status === 'mastered';
      }

      return matchSearch && matchCat && matchStatus;
    });
  }, [vocabList, searchQuery, selectedCategory, selectedStatus, now]);

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-4 animate-fadeIn">
      {/* Title */}
      <div>
        <h2 className="text-xl font-extrabold text-dune-900 tracking-tight">
          Bank Kosakata ({vocabList.length})
        </h2>
        <p className="text-xs text-dune-500">
          Kosakata frekuensi tinggi untuk komunikasi sehari-hari
        </p>
      </div>

      {/* Search Input Bar (Real-time Filter by Arabic or Indonesian) */}
      <div className="space-y-1.5">
        <div className="relative">
          <Search className="w-4 h-4 text-terracotta-700 absolute left-3.5 top-3.5" />
          <input
            type="text"
            data-testid="vocab-search-input"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari kata Indonesia atau Arab (contoh: buku / كِتَاب)..."
            className="w-full py-2.5 pl-10 pr-9 bg-[#faf6ef] border border-[#ddcaa8] focus:border-terracotta-600 rounded-2xl text-xs text-dune-900 placeholder:text-dune-400 focus:outline-none focus:ring-2 focus:ring-terracotta-500/20 shadow-2xs transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 p-1 rounded-full text-dune-400 hover:text-dune-700 hover:bg-[#ebdcc3]/60 transition-colors"
              title="Hapus pencarian"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {searchQuery.trim() && (
          <div className="flex items-center justify-between px-1 text-[11px] text-dune-600">
            <span>
              Menampilkan <strong>{filteredList.length}</strong> dari {vocabList.length} kata
            </span>
            <span className="text-[10px] text-terracotta-800 font-semibold bg-[#faeae0] border border-[#f4d4c0] px-1.5 py-0.5 rounded-md">
              Filter Real-time Aktif
            </span>
          </div>
        )}
      </div>

      {/* Status Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs font-semibold">
        {[
          { id: 'all', label: 'Semua' },
          { id: 'due', label: 'Siap Review' },
          { id: 'lapsed', label: 'Sering Salah' },
          { id: 'learning', label: 'Belajar' },
          { id: 'mastered', label: 'Mutqin' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setSelectedStatus(tab.id)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              selectedStatus === tab.id
                ? 'bg-terracotta-700 text-white shadow-xs'
                : 'bg-[#faf6ef] border border-[#e6d8c4] text-dune-700 hover:bg-[#f4eee2]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Category Horizontal Filter */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 text-[11px]">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-dune-900 text-amber-200 font-bold'
                : 'bg-[#ebdcc3]/60 text-dune-800 hover:bg-[#ebdcc3]'
            }`}
          >
            {cat === 'all' ? 'Semua Kategori' : cat}
          </button>
        ))}
      </div>

      {/* Vocab Cards List */}
      <div className="space-y-2.5">
        {filteredList.length === 0 ? (
          <div className="text-center py-12 bg-[#faf6ef] rounded-3xl border border-[#e6d8c4] p-6">
            <BookOpen className="w-10 h-10 text-dune-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-dune-800">Tidak ada kosakata yang cocok</p>
            <p className="text-xs text-dune-500 mt-1">Coba ganti kata kunci pencarian atau filter.</p>
          </div>
        ) : (
          filteredList.map(item => {
            const isDue = item.nextReviewDate <= now;
            const dueFormatted = SrsEngine.formatDueTime(item.nextReviewDate, now);

            return (
              <div
                key={item.id}
                onClick={() => setActiveItem(item)}
                className="p-3.5 bg-[#faf6ef] border border-[#e6d8c4] hover:border-terracotta-400 rounded-2xl shadow-xs flex items-center justify-between gap-3 cursor-pointer active:scale-[0.99] transition-all"
              >
                {/* Left: Indonesian meaning & tags */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-dune-950">{item.meaning}</span>
                    {item.status === 'mastered' && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold bg-amber-100 text-amber-900 border border-amber-300">
                        Mutqin
                      </span>
                    )}
                    {isDue && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 text-rose-900 border border-rose-200">
                        Due
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-terracotta-800 font-medium">
                    {item.transliteration}
                  </p>

                  <div className="flex items-center gap-2 text-[10px] text-dune-400">
                    <span>{item.category}</span>
                    <span>•</span>
                    <span>Level {item.masteryLevel}/5</span>
                  </div>
                </div>

                {/* Right: Arabic text & audio button */}
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-arabic text-2xl font-bold text-dune-950 select-none">
                    {item.arabic}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      audioService.speak(item.arabic);
                    }}
                    className="p-2 rounded-xl bg-[#ebdcc3]/60 hover:bg-[#faeae0] text-dune-700 hover:text-terracotta-800 transition-colors"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Item Detail Modal Sheet in Sandstone Parchment */}
      {activeItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#faf6ef] rounded-3xl p-6 shadow-2xl border border-[#e6d8c4] relative animate-scaleUp text-left">
            <button
              onClick={() => setActiveItem(null)}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-[#ebdcc3]/60 text-dune-400 hover:text-dune-700"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Category & Badge */}
            <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-[#faeae0] text-terracotta-800 border border-[#f4d4c0]">
              {activeItem.category}
            </span>

            {/* Arabic Word Display */}
            <div className="my-4 text-center">
              <span className="font-arabic text-5xl font-bold text-dune-950 block select-none">
                {activeItem.arabic}
              </span>
              <p className="text-terracotta-700 font-semibold text-sm mt-1">
                {activeItem.transliteration}
              </p>
              <p className="text-xl font-black text-dune-900 mt-2">
                {activeItem.meaning}
              </p>

              <button
                onClick={() => audioService.speak(activeItem.arabic)}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold bg-[#ebdcc3] text-dune-900 hover:bg-[#ddcaa8] transition-colors"
              >
                <Volume2 className="w-4 h-4 text-terracotta-700" />
                <span>Putar Suara Bahasa Arab</span>
              </button>
            </div>

            {/* Example sentence */}
            <div className="p-3.5 bg-[#f4eee2] border border-[#ddcaa8] rounded-2xl my-3">
              <div className="flex items-center justify-between text-xs font-bold text-dune-600 mb-1">
                <span>Contoh Kalimat:</span>
                <button
                  onClick={() => audioService.speak(activeItem.exampleArabic)}
                  className="text-terracotta-700 hover:underline flex items-center gap-1 font-semibold"
                >
                  <Volume2 className="w-3.5 h-3.5" /> Dengar
                </button>
              </div>
              <p className="font-arabic text-base font-bold text-dune-950 text-right my-1">
                {activeItem.exampleArabic}
              </p>
              <p className="text-xs text-dune-600 italic">
                "{activeItem.exampleMeaning}"
              </p>
            </div>

            {/* SRS Stats Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs text-dune-600 my-4">
              <div className="p-2.5 bg-[#f4eee2] rounded-xl border border-[#ddcaa8]">
                <span className="text-dune-400 block text-[10px]">Jadwal Review</span>
                <span className="font-bold text-dune-900">
                  {SrsEngine.formatDueTime(activeItem.nextReviewDate, now)}
                </span>
              </div>
              <div className="p-2.5 bg-[#f4eee2] rounded-xl border border-[#ddcaa8]">
                <span className="text-dune-400 block text-[10px]">Tingkat Penguasaan</span>
                <span className="font-bold text-dune-900">
                  Level {activeItem.masteryLevel} / 5
                </span>
              </div>
              <div className="p-2.5 bg-[#f4eee2] rounded-xl border border-[#ddcaa8]">
                <span className="text-dune-400 block text-[10px]">Total Salah (Lapse)</span>
                <span className="font-bold text-dune-900">
                  {activeItem.totalLapses} kali
                </span>
              </div>
              <div className="p-2.5 bg-[#f4eee2] rounded-xl border border-[#ddcaa8]">
                <span className="text-dune-400 block text-[10px]">Interval Hari</span>
                <span className="font-bold text-dune-900">
                  {activeItem.intervalDays} hari
                </span>
              </div>
            </div>

            {/* Study this word button */}
            <button
              onClick={() => {
                const itemToStudy = activeItem;
                setActiveItem(null);
                onStartSingleWordSession(itemToStudy);
              }}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-terracotta-700 to-amber-600 hover:from-terracotta-800 hover:to-amber-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-terracotta-900/20 active:scale-98 transition-all"
            >
              <Play className="w-4 h-4 fill-white text-white" />
              <span>Mulai Siklus Belajar Kata Ini</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
