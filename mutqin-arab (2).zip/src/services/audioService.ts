/**
 * High-Reliability Audio Service for Arabic Pronunciation
 *
 * Implements:
 * 1. Pre-buffering via fetch -> Blob -> URL.createObjectURL(blob)
 *    (Ensures the browser receives a complete audio file buffer with correct MIME type
 *    and doesn't get blocked by partial stream or CORS policy).
 * 2. Unlocks / resumes Web AudioContext and HTMLAudioElement on first user interaction.
 * 3. Graceful fallback to Web Speech Synthesis API (speechSynthesis).
 * 4. Auditory synthetic chime fallback if device speaker/network fails.
 */

class AudioService {
  private synth: SpeechSynthesis | null = null;
  private currentAudio: HTMLAudioElement | null = null;
  private currentBlobUrl: string | null = null;
  private audioContext: AudioContext | null = null;
  private isUnlocked = false;

  constructor() {
    if (typeof window !== 'undefined') {
      if ('speechSynthesis' in window) {
        this.synth = window.speechSynthesis;
      }
      // Listen to first click / touch anywhere to unlock audio policies
      const unlockAudio = () => {
        this.unlock();
        window.removeEventListener('click', unlockAudio);
        window.removeEventListener('touchstart', unlockAudio);
      };
      window.addEventListener('click', unlockAudio, { passive: true });
      window.addEventListener('touchstart', unlockAudio, { passive: true });
    }
  }

  /**
   * Unlock AudioContext and mobile browser media playback policies
   */
  public unlock() {
    if (this.isUnlocked) return;
    try {
      const ctx = this.getAudioContext();
      if (ctx && ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
      this.isUnlocked = true;
    } catch (e) {
      console.warn('Audio unlock warning:', e);
    }
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioContext) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.audioContext = new AudioCtx();
      }
    }
    if (this.audioContext && this.audioContext.state === 'suspended') {
      this.audioContext.resume().catch(() => {});
    }
    return this.audioContext;
  }

  /**
   * Synthesizer chime to guarantee auditory feedback
   */
  private playFallbackTone() {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.14); // A5
      gain.gain.setValueAtTime(0.25, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {
      console.warn('Fallback tone failed:', e);
    }
  }

  /**
   * Fetches TTS audio via same-origin proxy, converts to Blob Object URL,
   * and plays via standard HTML5 Audio constructor.
   * Default voice is 'male' for authentic Arabic male timbre and resonance.
   */
  private async playProxyArabicTTS(
    text: string,
    options: {
      rate?: number;
      voice?: 'male' | 'female';
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: any) => void;
    }
  ): Promise<boolean> {
    try {
      this.stop();

      const voice = options.voice || 'male';
      const encoded = encodeURIComponent(text.trim());
      const response = await fetch(`/api/tts?text=${encoded}&voice=${voice}`);

      if (!response.ok) {
        console.warn('Proxy TTS responded with status', response.status);
        return false;
      }

      const blob = await response.blob();
      if (!blob || blob.size === 0) {
        return false;
      }

      // Create local Blob URL
      const blobUrl = URL.createObjectURL(blob);
      this.currentBlobUrl = blobUrl;

      const audio = new Audio();
      this.currentAudio = audio;
      audio.src = blobUrl;

      if (options.rate && options.rate < 0.8) {
        audio.playbackRate = 0.8;
      } else {
        audio.playbackRate = 1.0;
      }

      return new Promise<boolean>((resolve) => {
        let isResolved = false;

        const cleanup = () => {
          if (this.currentBlobUrl) {
            URL.revokeObjectURL(this.currentBlobUrl);
            this.currentBlobUrl = null;
          }
        };

        audio.onplay = () => {
          options.onStart?.();
        };

        audio.onended = () => {
          cleanup();
          options.onEnd?.();
          if (!isResolved) {
            isResolved = true;
            resolve(true);
          }
        };

        audio.onerror = (e) => {
          console.warn('HTMLAudio error during playback:', e);
          cleanup();
          if (!isResolved) {
            isResolved = true;
            resolve(false);
          }
        };

        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              // Successfully started playback
            })
            .catch((err) => {
              console.warn('audio.play() prevented:', err);
              cleanup();
              if (!isResolved) {
                isResolved = true;
                resolve(false);
              }
            });
        }
      });
    } catch (err) {
      console.warn('playProxyArabicTTS error:', err);
      return false;
    }
  }

  /**
   * Speak Arabic text with fallback (Default: Suara Laki-Laki Khas Arab)
   */
  public async speak(
    text: string,
    options: {
      rate?: number;
      voice?: 'male' | 'female';
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: any) => void;
    } = {}
  ): Promise<void> {
    if (!text || !text.trim()) return;

    this.unlock();

    // Determine voice preference: explicitly passed option -> localStorage user profile -> default 'male'
    let selectedVoice: 'male' | 'female' = options.voice || 'male';
    if (!options.voice && typeof window !== 'undefined') {
      try {
        const savedProfile = localStorage.getItem('mutqin_arab_user_profile');
        if (savedProfile) {
          const parsed = JSON.parse(savedProfile);
          if (parsed && (parsed.voiceGender === 'female' || parsed.voiceGender === 'male')) {
            selectedVoice = parsed.voiceGender;
          }
        }
      } catch (e) {}
    }

    const effectiveOptions = { ...options, voice: selectedVoice };

    // 1. Primary: Dedicated Local Proxy -> Blob Object URL (Transformed into deep, resonant Arabic male voice)
    const proxySuccess = await this.playProxyArabicTTS(text, effectiveOptions);
    if (proxySuccess) {
      return;
    }

    // 2. Secondary: Web Speech Synthesis API
    if (this.synth) {
      try {
        this.synth.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'ar-SA';
        utterance.rate = options.rate ?? 0.82;
        // Pitch lowered to 0.78 for deep masculine chest voice on device engines
        utterance.pitch = (options.voice ?? 'male') === 'male' ? 0.78 : 1.0;

        const voices = this.synth.getVoices();
        const arabicVoice =
          voices.find(v => (v.lang === 'ar-SA' || v.lang === 'ar_SA') && (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('tarik') || v.name.toLowerCase().includes('hamed') || v.name.toLowerCase().includes('shakir') || v.name.toLowerCase().includes('maged'))) ||
          voices.find(v => v.lang === 'ar-SA' || v.lang === 'ar_SA') ||
          voices.find(v => v.lang.startsWith('ar'));
        if (arabicVoice) {
          utterance.voice = arabicVoice;
        }

        utterance.onstart = () => {
          options.onStart?.();
        };

        utterance.onend = () => {
          options.onEnd?.();
        };

        utterance.onerror = (err) => {
          if (err.error !== 'canceled') {
            this.playFallbackTone();
            options.onError?.(err);
          }
          options.onEnd?.();
        };

        this.synth.speak(utterance);
        return;
      } catch (e) {
        console.warn('SpeechSynthesis failed:', e);
      }
    }

    // 3. Fallback tone
    this.playFallbackTone();
    options.onStart?.();
    setTimeout(() => {
      options.onEnd?.();
    }, 300);
  }

  public stop() {
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.src = '';
      } catch (e) {}
      this.currentAudio = null;
    }
    if (this.currentBlobUrl) {
      URL.revokeObjectURL(this.currentBlobUrl);
      this.currentBlobUrl = null;
    }
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {}
    }
  }

  public isAvailable(): boolean {
    return true;
  }
}

export const audioService = new AudioService();
