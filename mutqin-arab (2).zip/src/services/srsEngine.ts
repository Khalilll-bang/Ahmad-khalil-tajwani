import { VocabularyItem, ConfidenceRating, MasteryStatus } from '../types';

/**
 * SuperMemo SM-2 & FSRS-inspired Spaced Repetition Engine for Arabic Vocabulary
 */
export class SrsEngine {
  // Constants for interval calculations (in minutes or days)
  private static readonly MIN_EASINESS_FACTOR = 1.3;
  private static readonly DEFAULT_EASINESS_FACTOR = 2.5;

  /**
   * Calculates the priority score of a vocabulary item.
   * Higher score = higher priority in the study queue.
   *
   * Priority Rules:
   * 1. Hampir Lupa (Due for review / overdue)
   * 2. Sering Salah (High lapse count, low retention)
   * 3. Baru Dipelajari (Newly introduced or learning stage)
   * 4. Penting untuk komunikasi sehari-hari (Importance 1-5 stars)
   */
  public static calculatePriorityScore(item: VocabularyItem, currentTime: number = Date.now()): number {
    let score = 0;

    const isDue = item.nextReviewDate <= currentTime;
    const hoursOverdue = isDue ? (currentTime - item.nextReviewDate) / (1000 * 60 * 60) : 0;

    // 1. Hampir Lupa / Overdue
    if (isDue) {
      score += 1500;
      // The more overdue, the more urgent to review before full memory decay
      score += Math.min(hoursOverdue * 10, 500);
    }

    // 2. Sering Salah (Lapses)
    score += item.totalLapses * 250;
    if (item.consecutiveCorrect === 0 && item.totalReviews > 0) {
      score += 200; // Just failed recently
    }

    // 3. Status Priority (Baru & Sedang Belajar)
    if (item.status === 'learning') {
      score += 400;
    } else if (item.status === 'new') {
      score += 300;
    } else if (item.status === 'reviewing' && !isDue) {
      // Due in near future
      const hoursUntilDue = (item.nextReviewDate - currentTime) / (1000 * 60 * 60);
      if (hoursUntilDue < 12) {
        score += (12 - hoursUntilDue) * 15;
      }
    }

    // 4. Penting untuk komunikasi sehari-hari (1 - 5)
    score += (item.importance || 3) * 80;

    // Low mastery bonus
    score += (5 - item.masteryLevel) * 40;

    return Math.round(score);
  }

  /**
   * Sorts vocabulary array by priority descending
   */
  public static sortByPriority(items: VocabularyItem[], currentTime: number = Date.now()): VocabularyItem[] {
    return [...items].sort((a, b) => {
      const scoreA = this.calculatePriorityScore(a, currentTime);
      const scoreB = this.calculatePriorityScore(b, currentTime);
      return scoreB - scoreA;
    });
  }

  /**
   * Applies SRS Confidence Rating to a vocabulary item
   * Ratings:
   * - 'again' (Tidak tahu): Reset interval, drop mastery, increase lapses
   * - 'hard' (Sulit): Shorter interval, slight EF drop
   * - 'good' (Sedang): Standard interval growth
   * - 'easy' (Mudah): Accelerated interval growth, boost EF
   */
  public static processReview(
    item: VocabularyItem,
    rating: ConfidenceRating,
    currentTime: number = Date.now()
  ): {
    updatedItem: VocabularyItem;
    explanation: string;
    nextDueFormatted: string;
  } {
    const copy = { ...item };
    copy.totalReviews += 1;
    copy.lastReviewedDate = currentTime;

    let newIntervalDays = 0;
    let newRepetition = copy.repetition;
    let newEasiness = copy.easinessFactor || this.DEFAULT_EASINESS_FACTOR;
    let newMastery = copy.masteryLevel;
    let newStatus: MasteryStatus = copy.status;
    let explanation = '';
    let nextDueFormatted = '';

    if (rating === 'again') {
      // User forgot or answered incorrectly
      copy.totalLapses += 1;
      copy.consecutiveCorrect = 0;
      newRepetition = 0;
      // Penalize EF
      newEasiness = Math.max(this.MIN_EASINESS_FACTOR, newEasiness - 0.2);

      // Mastery drops!
      newMastery = Math.max(1, newMastery - 1);
      newStatus = 'learning';

      // Due very soon (10 minutes)
      newIntervalDays = 10 / (24 * 60); // 10 minutes in days
      copy.nextReviewDate = currentTime + 10 * 60 * 1000;
      explanation = 'Tingkat penguasaan diturunkan. Kata ini dijadwalkan ulas kembali dalam 10 menit agar tidak hilang dari memori.';
      nextDueFormatted = '10 menit lagi';
    } else {
      copy.consecutiveCorrect += 1;
      newRepetition += 1;

      // Adjust Easiness Factor
      if (rating === 'hard') {
        newEasiness = Math.max(this.MIN_EASINESS_FACTOR, newEasiness - 0.15);
      } else if (rating === 'easy') {
        newEasiness += 0.15;
      }

      // Interval calculation
      if (newRepetition === 1) {
        newIntervalDays = rating === 'hard' ? 0.5 : rating === 'good' ? 1 : 2;
      } else if (newRepetition === 2) {
        newIntervalDays = rating === 'hard' ? 1.5 : rating === 'good' ? 3 : 5;
      } else {
        const factor = rating === 'hard' ? 1.2 : rating === 'good' ? newEasiness : newEasiness * 1.35;
        newIntervalDays = Math.round(Math.max(1, copy.intervalDays * factor) * 10) / 10;
      }

      // Mastery progression (0 to 5)
      if (rating === 'easy') {
        newMastery = Math.min(5, newMastery + 1);
      } else if (rating === 'good') {
        if (newRepetition >= 2 && newMastery < 4) newMastery += 1;
        if (newRepetition >= 5) newMastery = 5;
      } else if (rating === 'hard') {
        // Keep current or advance slowly
        if (newMastery === 0) newMastery = 1;
      }

      // Mastered rule: consecutive correct >= 4 and interval >= 14 days or mastery == 5
      if (newMastery >= 5 || (copy.consecutiveCorrect >= 4 && newIntervalDays >= 14)) {
        newStatus = 'mastered';
        newMastery = 5;
      } else if (newRepetition >= 2) {
        newStatus = 'reviewing';
      } else {
        newStatus = 'learning';
      }

      const intervalMillis = Math.round(newIntervalDays * 24 * 60 * 60 * 1000);
      copy.nextReviewDate = currentTime + intervalMillis;

      if (newIntervalDays < 1) {
        const hours = Math.round(newIntervalDays * 24);
        nextDueFormatted = `${hours} jam lagi`;
      } else if (newIntervalDays === 1) {
        nextDueFormatted = 'Besok (1 hari)';
      } else {
        nextDueFormatted = `${Math.round(newIntervalDays)} hari lagi`;
      }

      if (newStatus === 'mastered') {
        explanation = `Luar biasa! Kata ini telah mencapai status MUTQIN (Mastered). Interval pengulangan diperpanjang ke ${nextDueFormatted}.`;
      } else {
        explanation = `Bagus! Ingatanmu semakin kuat. Kata ini akan dijadwalkan ulang dalam ${nextDueFormatted}.`;
      }
    }

    copy.intervalDays = newIntervalDays;
    copy.repetition = newRepetition;
    copy.easinessFactor = Math.round(newEasiness * 100) / 100;
    copy.masteryLevel = newMastery;
    copy.status = newStatus;

    return {
      updatedItem: copy,
      explanation,
      nextDueFormatted,
    };
  }

  /**
   * Helper to format time remaining until next review
   */
  public static formatDueTime(nextReviewDate: number, currentTime: number = Date.now()): string {
    if (nextReviewDate <= currentTime) {
      const minutesOverdue = Math.floor((currentTime - nextReviewDate) / 60000);
      if (minutesOverdue < 60) return 'Siap sekarang';
      const hoursOverdue = Math.floor(minutesOverdue / 60);
      if (hoursOverdue < 24) return `Terlewat ${hoursOverdue} jam`;
      return `Terlewat ${Math.floor(hoursOverdue / 24)} hari`;
    }

    const diffMs = nextReviewDate - currentTime;
    const diffMinutes = Math.floor(diffMs / 60000);
    if (diffMinutes < 60) return `${diffMinutes} menit lagi`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours} jam lagi`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} hari lagi`;
  }
}
