import { VocabularyItem, UserStats, ReviewLog, UserProfile } from '../types';
import { INITIAL_VOCABULARY } from '../data/initialVocabulary';

const VOCAB_STORAGE_KEY = 'mutqin_arab_vocab_v1';
const STATS_STORAGE_KEY = 'mutqin_arab_stats_v1';
const LOGS_STORAGE_KEY = 'mutqin_arab_logs_v1';
const PROFILE_STORAGE_KEY = 'mutqin_arab_user_profile_v1';

export class StorageService {
  public static getUserProfile(): UserProfile | null {
    try {
      const data = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to load user profile:', e);
    }
    return null;
  }

  public static saveUserProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save user profile:', e);
    }
  }

  public static logoutUser(): void {
    try {
      localStorage.removeItem(PROFILE_STORAGE_KEY);
    } catch (e) {
      console.error('Failed to remove user profile:', e);
    }
  }

  /**
   * Get all vocabulary items. If first time, load initial curated vocabulary.
   */
  public static getVocabulary(): VocabularyItem[] {
    try {
      const data = localStorage.getItem(VOCAB_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to load vocabulary from storage:', e);
    }
    // First time initialization
    this.saveVocabulary(INITIAL_VOCABULARY);
    return INITIAL_VOCABULARY;
  }

  public static saveVocabulary(items: VocabularyItem[]): void {
    try {
      localStorage.setItem(VOCAB_STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save vocabulary:', e);
    }
  }

  public static updateVocabularyItem(item: VocabularyItem): void {
    const list = this.getVocabulary();
    const index = list.findIndex(v => v.id === item.id);
    if (index !== -1) {
      list[index] = item;
      this.saveVocabulary(list);
    }
  }

  public static getStats(): UserStats {
    const defaultStats: UserStats = {
      dailyStreak: 1,
      lastActiveDate: new Date().toISOString().split('T')[0],
      todayReviewedCount: 0,
      totalWordsLearned: 0,
      totalReviewsEver: 0,
      masteredCount: 0,
      retentionRatePercent: 88,
    };

    try {
      const data = localStorage.getItem(STATS_STORAGE_KEY);
      if (data) {
        const stats: UserStats = JSON.parse(data);
        const today = new Date().toISOString().split('T')[0];

        // Check streak
        if (stats.lastActiveDate !== today) {
          const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
          if (stats.lastActiveDate === yesterday) {
            stats.dailyStreak += 1;
          } else {
            // Missed more than 1 day
            stats.dailyStreak = 1;
          }
          stats.todayReviewedCount = 0;
          stats.lastActiveDate = today;
          this.saveStats(stats);
        }
        return stats;
      }
    } catch (e) {
      console.error('Failed to load stats:', e);
    }

    this.saveStats(defaultStats);
    return defaultStats;
  }

  public static saveStats(stats: UserStats): void {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    } catch (e) {
      console.error('Failed to save stats:', e);
    }
  }

  public static getLogs(): ReviewLog[] {
    try {
      const raw = localStorage.getItem(LOGS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error('Failed to get logs:', e);
      return [];
    }
  }

  public static logReview(log: ReviewLog): void {
    try {
      const raw = localStorage.getItem(LOGS_STORAGE_KEY);
      const logs: ReviewLog[] = raw ? JSON.parse(raw) : [];
      logs.unshift(log);
      // Keep up to 200 logs
      if (logs.length > 200) logs.pop();
      localStorage.setItem(LOGS_STORAGE_KEY, JSON.stringify(logs));

      // Update aggregate stats
      const stats = this.getStats();
      stats.todayReviewedCount += 1;
      stats.totalReviewsEver += 1;

      // Recalculate mastered words
      const vocab = this.getVocabulary();
      stats.masteredCount = vocab.filter(v => v.status === 'mastered').length;
      stats.totalWordsLearned = vocab.filter(v => v.status !== 'new').length;

      // Calculate retention rate based on lapses vs total reviews
      const totalReviews = vocab.reduce((sum, v) => sum + v.totalReviews, 0);
      const totalLapses = vocab.reduce((sum, v) => sum + v.totalLapses, 0);
      if (totalReviews > 0) {
        stats.retentionRatePercent = Math.round(
          Math.max(0, Math.min(100, ((totalReviews - totalLapses) / totalReviews) * 100))
        );
      }

      this.saveStats(stats);
    } catch (e) {
      console.error('Failed to log review:', e);
    }
  }

  public static resetProgress(): void {
    localStorage.removeItem(VOCAB_STORAGE_KEY);
    localStorage.removeItem(STATS_STORAGE_KEY);
    localStorage.removeItem(LOGS_STORAGE_KEY);
    this.saveVocabulary(INITIAL_VOCABULARY);
  }
}
