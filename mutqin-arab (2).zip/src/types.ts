export type MasteryStatus = 'new' | 'learning' | 'reviewing' | 'mastered';

export type ConfidenceRating = 'again' | 'hard' | 'good' | 'easy';

export type TestType = 'multiple_choice' | 'listening' | 'typing' | 'matching' | 'sentence_scramble';

export interface VocabularyItem {
  id: string;
  arabic: string; // With full harakat
  arabicClean: string; // Without harakat for search
  transliteration: string; // Latin pronunciation
  meaning: string; // Indonesian meaning
  wordType: 'isim' | 'fiil' | 'harf';
  category: string; // Daily category
  importance: number; // 1 to 5 stars (relevance for daily communication)
  rootWord?: string; // Akar kata / wazan
  exampleArabic: string; // Full Arabic example sentence
  exampleTransliteration: string;
  exampleMeaning: string;
  sentenceWords: string[]; // Scrambled pieces for sentence arrangement test
  distractors: string[]; // 3 alternate Indonesian meanings for tests
  arabicDistractors?: string[]; // Alternate Arabic words for listening/multiple choice

  // SRS Metadata
  status: MasteryStatus;
  repetition: number; // consecutive correct reviews
  intervalDays: number; // current interval in days
  easinessFactor: number; // default 2.5
  nextReviewDate: number; // timestamp in epoch ms
  lastReviewedDate?: number; // timestamp in epoch ms
  masteryLevel: number; // 0 to 5 (0: Baru, 1: Dikenalkan, 2: Recall, 3: Teruji, 4: Lancar, 5: Mutqin)
  totalReviews: number;
  totalLapses: number; // number of times answered 'again' or failed test
  consecutiveCorrect: number;
}

export interface UserProfile {
  name: string;
  schoolName: string;
  isLoggedIn: boolean;
  loginDate?: string;
  dailyGoal?: number; // Target harian jumlah kosakata yang dipelajari/direview (default 15)
  voiceGender?: 'male' | 'female'; // Preferensi suara pelafalan Arab ('male': Suara Pria Khas Arab/Fasikh, 'female': Standar)
}

export interface ReviewLog {
  id: string;
  vocabId: string;
  timestamp: number;
  rating: ConfidenceRating;
  previousInterval: number;
  newInterval: number;
  previousMastery: number;
  newMastery: number;
  testPassed?: boolean;
}

export interface UserStats {
  dailyStreak: number;
  lastActiveDate: string; // YYYY-MM-DD
  todayReviewedCount: number;
  totalWordsLearned: number;
  totalReviewsEver: number;
  masteredCount: number;
  retentionRatePercent: number;
}
