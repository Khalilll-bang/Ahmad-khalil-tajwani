/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        desert: {
          50: '#fbf8f2',
          100: '#f6efe0',
          200: '#ebdcc3',
          300: '#ddc4a0',
          400: '#caa576',
          500: '#b58851',
          600: '#9c6d37',
          700: '#7d5226',
          800: '#5f3c1b',
          900: '#3d2510',
          950: '#261608',
        },
        dune: {
          50: '#faf6f0',
          100: '#f3ebe0',
          200: '#e6d6c2',
          300: '#d4bba0',
          400: '#be9a77',
          500: '#a47c55',
          600: '#87603d',
          700: '#6a492e',
          800: '#4f3521',
          900: '#352316',
          950: '#21150c',
        },
        terracotta: {
          50: '#fdf6f0',
          100: '#faeae0',
          200: '#f4d4c0',
          300: '#ebb394',
          400: '#df8c63',
          500: '#cf6836',
          600: '#b84e23',
          700: '#943b19',
          800: '#773017',
          900: '#522110',
          950: '#301308',
        },
        sand: {
          50: '#fdfbf7',
          100: '#f8f3eb',
          200: '#f0e5d4',
          300: '#e3cfb5',
          400: '#d2b48e',
          500: '#bc9568',
          600: '#9f764a',
          700: '#7f5b37',
          800: '#5d4127',
          900: '#3c2817',
          950: '#23160b',
        },
        emerald: {
          850: '#064e3b',
          950: '#022c22',
        },
        gold: {
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
        }
      },
      fontFamily: {
        arabic: ['"Amiri"', '"Scheherazade New"', 'Traditional Arabic', 'Tahoma', 'sans-serif'],
      },
      keyframes: {
        wiggle: {
          '0%, 100%': { transform: 'rotate(-3deg)' },
          '50%': { transform: 'rotate(3deg)' },
        }
      },
      animation: {
        wiggle: 'wiggle 0.3s ease-in-out infinite',
      }
    },
  },
  plugins: [],
}
