import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { spawn } from 'child_process';

export default defineConfig({
  plugins: [
    react(),
    {
      name: 'arabic-tts-proxy',
      configureServer(server) {
        server.middlewares.use('/api/tts', async (req, res) => {
          // Handle CORS preflight if any
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
          res.setHeader('Access-Control-Allow-Headers', '*');

          if (req.method === 'OPTIONS') {
            res.statusCode = 204;
            res.end();
            return;
          }

          try {
            const urlObj = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
            const text = urlObj.searchParams.get('text') || '';
            const voice = urlObj.searchParams.get('voice') || 'male'; // 'male' is default
            if (!text || !text.trim()) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'text/plain; charset=utf-8');
              res.end('Missing text');
              return;
            }

            const cleanText = text.trim();
            const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(
              cleanText
            )}&tl=ar&client=tw-ob`;

            const upstreamRes = await fetch(ttsUrl, {
              headers: {
                'User-Agent':
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                Referer: 'https://translate.google.com/',
                Accept: '*/*',
              },
            });

            if (!upstreamRes.ok) {
              res.statusCode = upstreamRes.status;
              res.setHeader('Content-Type', 'text/plain; charset=utf-8');
              res.end(`Upstream TTS error: ${upstreamRes.status}`);
              return;
            }

            const arrayBuffer = await upstreamRes.arrayBuffer();
            const inputBuffer = Buffer.from(arrayBuffer);

            // If voice is male, transform acoustic formant and pitch to deep authentic Arabic male tone
            if (voice === 'male') {
              try {
                // Pitch down to authentic male vocal register (0.83x), preserve tempo (1/0.83), boost chest resonance (+5dB bass at 180Hz)
                const ffmpeg = spawn('ffmpeg', [
                  '-i', 'pipe:0',
                  '-filter:a', 'asetrate=24000*0.83,atempo=1/0.83,bass=g=5:f=180,treble=g=-1:f=3500',
                  '-f', 'mp3',
                  'pipe:1',
                ]);

                const chunks: Buffer[] = [];
                ffmpeg.stdout.on('data', (c) => chunks.push(c));
                ffmpeg.stderr.on('data', () => {}); // silence ffmpeg logs

                ffmpeg.on('close', (code) => {
                  if (code === 0 && chunks.length > 0) {
                    const maleBuffer = Buffer.concat(chunks);
                    res.statusCode = 200;
                    res.setHeader('Content-Type', 'audio/mpeg');
                    res.setHeader('Content-Length', maleBuffer.length.toString());
                    res.setHeader('Accept-Ranges', 'bytes');
                    res.setHeader('Cache-Control', 'public, max-age=86400, immutable');
                    res.end(maleBuffer);
                  } else {
                    // Fallback to original buffer
                    res.statusCode = 200;
                    res.setHeader('Content-Type', 'audio/mpeg');
                    res.setHeader('Content-Length', inputBuffer.length.toString());
                    res.setHeader('Accept-Ranges', 'bytes');
                    res.setHeader('Cache-Control', 'public, max-age=86400, immutable');
                    res.end(inputBuffer);
                  }
                });

                ffmpeg.on('error', () => {
                  res.statusCode = 200;
                  res.setHeader('Content-Type', 'audio/mpeg');
                  res.setHeader('Content-Length', inputBuffer.length.toString());
                  res.end(inputBuffer);
                });

                ffmpeg.stdin.write(inputBuffer);
                ffmpeg.stdin.end();
                return;
              } catch (e) {
                // Fallback to unmodified buffer
              }
            }

            res.statusCode = 200;
            res.setHeader('Content-Type', 'audio/mpeg');
            res.setHeader('Content-Length', inputBuffer.length.toString());
            res.setHeader('Accept-Ranges', 'bytes');
            res.setHeader('Cache-Control', 'public, max-age=86400, immutable');
            res.end(inputBuffer);
          } catch (error) {
            console.error('TTS Proxy Error:', error);
            res.statusCode = 500;
            res.setHeader('Content-Type', 'text/plain; charset=utf-8');
            res.end('Internal Server Error');
          }
        });
      },
    },
  ],
  server: {
    host: '0.0.0.0',
    port: 3000,
  },
});
